# FileZen
Premium file manager for Android (Capacitor).

1. Upload everything in this folder to a new GitHub repo (keep `.github` folder).
2. Open the **Actions** tab -> "Build APK" runs automatically (or press Run workflow).
3. When it finishes, download **FileZen-APK** from the run's Artifacts, unzip, install `app-debug.apk`.
4. On first launch tap **Allow** and enable "All files access" for FileZen.

Opening `www/index.html` in a browser runs a demo with sample files.
