# FileZen 3.0

A premium Android file manager. Capacitor shell, native-grade UI, zero network code.

## Install the APK

1. Put this folder's contents in a GitHub repo (keep `.github/`). Uploading just `FileZen.zip`
   works too — the workflow unzips it automatically.
2. Open **Actions → Build APK** (it runs on push, or press *Run workflow*).
3. Download the **FileZen-APK** artifact, unzip, install `app-debug.apk`.
4. First launch: tap **Allow access** and enable "All files access" for FileZen.

## Design — 3.0

Rebuilt around native conventions instead of web ones:

- Neutral surfaces (`#0B0B0D` → `#151519`), hairline dividers, **one** accent colour.
- Grouped lists with real dividers instead of a card per row; grid view uses quiet tiles.
- Material 3 bottom navigation with an active-item pill, M3 motion curves, circular
  icon buttons with ripple, restrained elevation.
- Type scale uses the system font (Roboto on Android) at 400/550/650 weights — no
  gradient text, no glow, no emoji.
- 6 themes: Aurora, Nebula, Noir, Ocean, Sunset, Daylight. 8 accents.
- The **status bar and navigation bar are painted natively** to match the theme
  (`Chrome` plugin), so the app never looks like a page inside a frame.

## Motion

Transform/opacity only. No animated blur, no backdrop blur on scrolling content.
Lists render in chunks of 64, thumbnails load through an IntersectionObserver, and
`Animations` / `Glass blur` switches give a one-tap performance mode. `prefers-reduced-motion`
is respected.

## Features

Image viewer (pinch zoom, double-tap, pan, swipe gallery, filmstrip) · video and audio
players with a mini player · text editor with save · Trash with restore and Undo ·
global search with type filters · command palette · long-press shortcut sheet (Open,
Share, Open with, Pin, Copy, Cut, Rename, Delete, Details) · pins and editable Quick
access · storage insights · multi-select bulk actions · sort sheet · list/grid ·
hidden files · lazy thumbnails · per-screen scroll memory · keyboard shortcuts.

## Build notes

There is exactly **one** native plugin file (`native/PermPlugin.java`) and one
`native/MainActivity.java`, so any workflow that copies those two compiles. `PermPlugin`
imports nothing outside the Android framework and Capacitor core — `FileProvider` is
reached through reflection — so it builds even when `androidx.core` is not on the app
module's classpath, and it never crashes if the provider is missing.

`PermPlugin` provides: "All files access" check/request, storage totals, Open with,
Share, and status/navigation bar colours.

`.github/workflows/build-apk.yml` writes those same two files itself and also adds the
`FileProvider` entry plus permissions to the manifest, so a repo that only contains the
zip still builds. Both paths produce the same result.

Permissions added: `MANAGE_EXTERNAL_STORAGE`, legacy read/write, and the `READ_MEDIA_*` set.

## Preview

Open `www/index.html` in a browser — it runs a full demo with sample folders, generated
images and text files.
