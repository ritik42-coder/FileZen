# FileZen 4.1

A premium Android file manager. Capacitor shell + a small native engine. No network code.

## Install (phone only, no PC needed)

1. Upload this whole folder to a GitHub repo — or just upload `FileZen.zip`; the workflow unzips it.
   (Keep the hidden `.github` folder if you upload files one by one.)
2. Open **Actions → Build APK** and press **Run workflow** (it also runs on every push).
3. When it turns green, open the run → download the **FileZen-APK** artifact → unzip → install `app-debug.apk`.
4. First launch: tap **Allow access** and switch on "All files access" for FileZen.

**Updating over the old app:** install the new APK on top. Your pins, shortcuts and settings are kept.

## New in 4.1 — Air Drag

**Long-press any file or folder** and it lifts off the list and floats under your finger
(it tilts with your motion; select several first to carry them all as a stack).

* **Drop on a folder** to move it there, or on a **breadcrumb** to move it up. Hover on a folder or
  breadcrumb for a moment and it **opens under your finger**, so you can drag deep into the tree.
  A bar at the top says exactly what will happen ("Move to Projects").
* **Drop zones** rise at the bottom: **Compress**, **Share**, **Delete**.
* **Release in open space** and the files **stay in the air** in a tray. Browse anywhere (other folders,
  other tabs) and tap **Drop here**; they fly in and the new rows light up. You can also drag the tray's
  stack straight onto a folder.
* **Move / Copy**: switch in the tray, or **tap a second finger** while dragging.
* Every move or copy has an **Undo**.
* Long-press and release without moving still opens the menu, exactly as before.

### Scrolling
* **Rubber-band overscroll** on every screen and **pull-to-refresh** on Home and Files.
* Rows **ease in** (scale + fade) as they near the top and bottom edges.
* Home hero card **parallax**, cards **reveal** as you scroll to them.
* **Scroll-to-top button** with a live progress ring (also: double-tap the title bar).
* Header collapses, fast-scroller bubble, springs on tabs, sheets and dialogs.

## What changed in 4.0

### Instant everything (no more "Scanning…")
* A **native storage index** walks your whole phone in about a second on a background thread and
  is cached on the device. Categories (Images, Videos, Audio, Documents, Archives, Apps),
  Recent, Large files and Search all read from memory, so they open **instantly**.
* The app starts with last session's index, so counts and categories are there the moment it opens;
  it refreshes silently in the background.
* Folders open from a cache and are **pre-loaded the instant your finger touches them**, then
  quietly refresh. Going back restores your exact scroll position.

### Smooth scrolling
* **Virtual list**: only ~25 rows exist at any time, so 5,000 photos scroll like 50.
* **Native thumbnails**: small cached images generated on a background thread (photos, video frames,
  APK icons, album art). Before, every photo loaded at full size, which was the main cause of lag.
* The always-animating blurred background was replaced by a static gradient (it repainted every frame).
* The app asks Android for your screen's **highest refresh rate** (90/120 Hz where supported).
* **Fast scroller**: drag the handle on the right edge; a bubble shows the letter / month / size you are at.
* Header title shrinks as you scroll, folder changes slide in the direction you are moving,
  tabs slide, rows stagger in, numbers count up, sheets can be **dragged down** to close.

### Search
Instant as you type, ranked (starts-with first), highlights matches, finds folders too,
filter chips, recent searches, and quick suggestions.

### New features
* **Compress to ZIP**: files or whole folders, with progress ring and Cancel.
* **Extract**: `.zip .jar .apk .cbz .xapk .tar .tar.gz .tgz .gz`, "Extract here" or "Extract to…",
  with zip-slip protection, never overwrites (adds `(1)`).
* **Browse inside archives** without extracting.
* **Move to… / Copy to…** with a folder picker (and New folder).
* **Duplicates finder** (content fingerprint, "Select extras" keeps the oldest), **Large files**, **Recent**.
* **Share many files** at once (it only shared the first one before).
* Folder size in Details, thumbnail-cache clear button, Gallery stays in sync after changes.
* Image viewer: instant 1280px previews (original loads only when you zoom in), swipe-down to close,
  neighbour pre-loading, lightweight filmstrip.

### Not supported
Password-protected ZIPs and `.rar` / `.7z` (Android has no built-in reader for them). Those open
with "Open with…" in another app.

## Build notes
Native code lives in `native/`: `PermPlugin.java` (Capacitor bridge, thumbnails, and the `FzCore`
engine for index/zip/extract/hashing, kept in the same file) and `MainActivity.java`.
The workflow writes these two files itself, so a repo that only contains the zip still builds.

## Preview
Open `www/index.html` in a browser for a demo with 1,400+ generated photos.
