# FileZen 2.0

A premium, buttery-smooth file manager for Android (Capacitor).

## What's new in 2.0

**Completely rebuilt UI**
- New "Aurora" design language: soft mesh light, hairline borders, floating glass chrome.
- 6 full themes — Aurora, Nebula, Noir, Ocean, Sunset, Daylight — plus 8 accent colours.
- Real icon set (no emoji), consistent 1.8px stroke geometry.

**Motion that never stutters**
- Animations are transform/opacity only — no animated blur filters, no per-row backdrop blur.
- Rows render in chunks of 64 with an IntersectionObserver for thumbnails, so folders with
  thousands of files stay smooth.
- Screen transitions, spring-pressed buttons, staggered card reveals, sliding tab pill,
  spring bottom sheets, morphing dialogs, ripple feedback.
- `Animations` and `Glass blur` switches in Settings give you a one-tap performance mode
  for older devices. `prefers-reduced-motion` is respected automatically.

**Fixed**
- Tapping an image now always shows it: dedicated viewer with a real loading state,
  error fallback + "Open with another app", pinch-zoom, double-tap zoom, pan, swipe
  between images and a filmstrip.
- Long-press no longer fights with scrolling; the shortcut menu is a full action sheet.

**New features**
- Image viewer: pinch / double-tap zoom, pan, swipe gallery, filmstrip.
- Video player and audio player with a floating mini-player.
- Built-in text editor — open a .txt/.md/.json/.js file, edit and save it.
- Trash: deleted files are recoverable until you empty it (with Undo toast).
- Global search across all storage with type filters and match highlighting.
- Command palette (⌘K style) for jumping anywhere or running any action.
- Shortcut menu on long-press / ⋮: Open, Share, Open with, Pin, Copy, Cut, Rename, Delete, Details.
- Pins ("Pinned" on Home) and Quick access shortcuts you can edit.
- Storage insights: usage by file type plus your largest files.
- Multi-select with bulk actions (copy, cut, share, pin, invert, delete).
- Sort sheet (name/date/size/type + direction), list & grid layouts, hidden files toggle.
- Image thumbnails in the browser, lazy-loaded.
- Pull-through chunked scrolling, per-screen scroll memory, keyboard shortcuts on desktop.

## Build the APK

1. Upload everything in this folder to a new GitHub repo (keep the `.github` folder).
2. Open the **Actions** tab → **Build APK** runs automatically (or press *Run workflow*).
3. When it finishes, download the **FileZen-APK** artifact, unzip it, install `app-debug.apk`.
4. On first launch tap **Allow access** and enable "All files access" for FileZen.

## Preview without building

Open `www/index.html` in any browser. It runs a fully working demo with sample files,
generated images, folders and text documents.

## Notes

- Everything is local. FileZen has no network code and never uploads a file.
- `native/` holds the small native additions: `PermPlugin` (storage stats + permission
  request) and `FileOpenerPlugin` (Open with / Share through a FileProvider). The workflow
  copies them in, adds the permissions and the FileProvider to the manifest, and builds.
