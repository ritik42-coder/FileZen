# FileZen 4.2

A premium Android file manager. Capacitor shell + a small native engine. No network code.

## Install (phone only, no PC needed)

1. Upload this whole folder to a GitHub repo — or just upload `FileZen.zip`; the workflow unzips it.
   (Keep the hidden `.github` folder if you upload files one by one.)
2. Open **Actions → Build APK** and press **Run workflow** (it also runs on every push).
3. When it turns green, open the run → download the **FileZen-APK** artifact → unzip → install `app-debug.apk`.
4. First launch: tap **Allow access** and switch on "All files access" for FileZen.

**Updating over the old app:** install the new APK on top. Your pins, shortcuts and settings are kept.

## New in 4.2

### Air scrolling (replaces the old scroll effects)
Scrolling now has physics: rows **stretch apart with your speed**, icons **trail behind their text**,
rows **tilt in 3D**, and everything **settles with a floaty overshoot**. Nothing fades or overlaps.
Switch it off in **Settings → Air scrolling**. The 3D tilt only runs on capable phones and turns itself
off if it ever sees slow frames. (The old fade/scale edge effect, rubber-band overscroll, parallax and
folder-slide animation were removed.) Pull-to-refresh now just drops an indicator from the header.

### Air transfer 2.0
**Long-press** a file or folder: it lifts, floats under your finger with a trail of air, and tilts as you move.
* **Many files:** select several first, or **tap a second finger on more files while dragging** to add
  them to the stack (tap again to remove). Everything you carry shows as a fanned stack with a count.
* **Go anywhere while carrying:** push to the **left edge** and hold to go **back** a folder (keep holding
  to keep climbing). **Hover the Home / Files tab** to switch tabs without letting go. Hover a folder or
  breadcrumb to open it. On Home, drop straight onto a **shortcut chip**.
* **Drop zones:** Compress, Share, Delete. A top bar says exactly what will happen.
* **Release in open space** and the files **stay in the air** in a tray. Lift more files later and they
  **join the stack**. The tray lists every file with a remove button, has its own **Back** button, and
  **Move / Copy** switch. Tap **Drop here** in any folder (or drag the stack onto a folder).
* Each file flies on its own path, with a burst where it lands. Every move or copy has **Undo**.

## What changed in 4.0

### Instant everything (no more "Scanning…")
* A **native storage index** walks your whole phone in about a second on a background thread and
  is cached on the device. Categories (Images, Videos, Audio, Documents, Archives, Apps),
  Recent, Large files and Search all read from memory, so they open **instantly**.
* The app starts with last session's index, so counts and categories are there the moment it opens;
  it refreshes silently in the background.
* Folders open from a cache and are **pre-loaded the instant your finger touches them**, then
  quietly refresh. Going back restores your exact scroll position.

### Smooth scrolling
* **Virtual list**: only ~25 rows exist at any time, so 5,000 photos scroll like 50.
* **Native thumbnails**: small cached images generated on a background thread (photos, video frames,
  APK icons, album art). Before, every photo loaded at full size, which was the main cause of lag.
* The always-animating blurred background was replaced by a static gradient (it repainted every frame).
* The app asks Android for your screen's **highest refresh rate** (90/120 Hz where supported).
* **Fast scroller**: drag the handle on the right edge; a bubble shows the letter / month / size you are at.
* Header title shrinks as you scroll, folder changes slide in the direction you are moving,
  tabs slide, rows stagger in, numbers count up, sheets can be **dragged down** to close.

### Search
Instant as you type, ranked (starts-with first), highlights matches, finds folders too,
filter chips, recent searches, and quick suggestions.

### New features
* **Compress to ZIP**: files or whole folders, with progress ring and Cancel.
* **Extract**: `.zip .jar .apk .cbz .xapk .tar .tar.gz .tgz .gz`, "Extract here" or "Extract to…",
  with zip-slip protection, never overwrites (adds `(1)`).
* **Browse inside archives** without extracting.
* **Move to… / Copy to…** with a folder picker (and New folder).
* **Duplicates finder** (content fingerprint, "Select extras" keeps the oldest), **Large files**, **Recent**.
* **Share many files** at once (it only shared the first one before).
* Folder size in Details, thumbnail-cache clear button, Gallery stays in sync after changes.
* Image viewer: instant 1280px previews (original loads only when you zoom in), swipe-down to close,
  neighbour pre-loading, lightweight filmstrip.

### Not supported
Password-protected ZIPs and `.rar` / `.7z` (Android has no built-in reader for them). Those open
with "Open with…" in another app.

## Build notes
Native code lives in `native/`: `PermPlugin.java` (Capacitor bridge, thumbnails, and the `FzCore`
engine for index/zip/extract/hashing, kept in the same file) and `MainActivity.java`.
The workflow writes these two files itself, so a repo that only contains the zip still builds.

## Preview
Open `www/index.html` in a browser for a demo with 1,400+ generated photos.
