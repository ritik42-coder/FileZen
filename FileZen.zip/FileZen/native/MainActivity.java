package com.filezen.app;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(PermPlugin.class);
        super.onCreate(savedInstanceState);
        try {
            Window w = getWindow();
            w.setStatusBarColor(Color.parseColor("#0B0B0D"));
            w.setNavigationBarColor(Color.parseColor("#0B0B0D"));
            View dv = w.getDecorView();
            dv.setSystemUiVisibility(dv.getSystemUiVisibility() & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        } catch (Exception ignored) {}
    }
}
