package com.filezen.app;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(PermPlugin.class);
        super.onCreate(savedInstanceState);
        try {
            Window w = getWindow();
            w.setStatusBarColor(Color.parseColor("#0B0B0D"));
            w.setNavigationBarColor(Color.parseColor("#0B0B0D"));
            View dv = w.getDecorView();
            dv.setSystemUiVisibility(dv.getSystemUiVisibility() & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        } catch (Exception ignored) {}
        requestSmoothDisplay();
    }

    /** Ask Android for the highest refresh rate the screen supports (90/120 Hz) so scrolling feels silky. */
    private void requestSmoothDisplay() {
        try {
            if (Build.VERSION.SDK_INT < 23) return;
            Display d = getWindowManager().getDefaultDisplay();
            Display.Mode cur = d.getMode();
            Display.Mode best = cur;
            for (Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() == cur.getPhysicalWidth()
                        && m.getPhysicalHeight() == cur.getPhysicalHeight()
                        && m.getRefreshRate() > best.getRefreshRate()) {
                    best = m;
                }
            }
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.preferredDisplayModeId = best.getModeId();
            getWindow().setAttributes(lp);
        } catch (Throwable ignored) {}
    }
}
