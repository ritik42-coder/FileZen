package com.filezen.app;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.Deflater;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.ConnectException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.BufferedInputStream;
import java.io.EOFException;
import java.util.Map;
import java.util.HashMap;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * FileZen core engine. Pure Java (no Android imports) so it is fast, safe and unit-testable.
 * Everything here is meant to run on a background thread.
 */
public final class FzCore {

    private FzCore() {}

    /* ------------------------------------------------------------------ */
    /* progress + cancel                                                    */
    /* ------------------------------------------------------------------ */

    public interface Progress {
        void onProgress(long done, long total, String name);
        boolean cancelled();
    }

    public static class Cancelled extends IOException {
        public Cancelled() { super("cancelled"); }
    }

    /** Throttles progress callbacks so the UI bridge is never flooded. */
    private static final class Ticker {
        final Progress p; final long total; long done; long last; String name = "";
        Ticker(Progress p, long total) { this.p = p; this.total = total; }
        void add(long n, String nm) throws IOException {
            done += n;
            if (nm != null) name = nm;
            if (p == null) return;
            if (p.cancelled()) throw new Cancelled();
            long now = System.currentTimeMillis();
            if (now - last >= 90) { last = now; p.onProgress(done, total, name); }
        }
        void finish() { if (p != null) p.onProgress(total > 0 ? total : done, total, name); }
    }

    /* ------------------------------------------------------------------ */
    /* helpers                                                              */
    /* ------------------------------------------------------------------ */

    static String ext(String n) {
        int i = n.lastIndexOf('.');
        return i > 0 ? n.substring(i + 1).toLowerCase(Locale.ROOT) : "";
    }

    /** Returns f, or "name (1).ext", "name (2).ext"… if it already exists. */
    public static File unique(File f) {
        if (!f.exists()) return f;
        File dir = f.getParentFile();
        String n = f.getName();
        String low = n.toLowerCase(Locale.ROOT);
        String b = n, e = "";
        if (low.endsWith(".tar.gz")) { b = n.substring(0, n.length() - 7); e = n.substring(n.length() - 7); }
        else {
            int i = n.lastIndexOf('.');
            if (i > 0) { b = n.substring(0, i); e = n.substring(i); }
        }
        for (int c = 1; c < 10000; c++) {
            File g = new File(dir, b + " (" + c + ")" + e);
            if (!g.exists()) return g;
        }
        return f;
    }

    /** True when f is a symlink that points outside its parent (loop guard). */
    private static boolean escapes(File f, String parentCanon) {
        try {
            String c = f.getCanonicalPath();
            return !c.startsWith(parentCanon + File.separator);
        } catch (IOException e) {
            return true;
        }
    }

    private static boolean isZipName(String low) {
        return low.endsWith(".zip") || low.endsWith(".jar") || low.endsWith(".cbz") || low.endsWith(".xapk")
                || low.endsWith(".apks") || low.endsWith(".apk") || low.endsWith(".aab");
    }

    private static boolean isTarGz(String low) { return low.endsWith(".tar.gz") || low.endsWith(".tgz"); }

    private static boolean isTar(String low) { return low.endsWith(".tar"); }

    private static boolean isGz(String low) { return low.endsWith(".gz"); }

    public static boolean canExtract(String name) {
        String low = name.toLowerCase(Locale.ROOT);
        return isZipName(low) || isTarGz(low) || isTar(low) || isGz(low);
    }

    /** Folder name used when extracting "here": archive name without its extension(s). */
    public static String stem(String name) {
        String low = name.toLowerCase(Locale.ROOT);
        if (low.endsWith(".tar.gz")) return name.substring(0, name.length() - 7);
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(0, i) : name + "_extracted";
    }

    private static String jstr(String s) {
        StringBuilder b = new StringBuilder(s.length() + 8);
        b.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\') { b.append('\\').append(c); }
            else if (c < 0x20) { b.append(String.format("\\u%04x", (int) c)); }
            else b.append(c);
        }
        return b.append('"').toString();
    }

    /* ------------------------------------------------------------------ */
    /* storage index                                                        */
    /* ------------------------------------------------------------------ */

    /**
     * Walks the whole tree once and writes a compact JSON array:
     * [[path,size,mtime,isDir],…]. Hidden (dot) entries and Android/ are skipped.
     * Returns the number of entries written.
     */
    public static int index(File root, File out, int maxDepth) throws IOException {
        File tmp = new File(out.getPath() + ".tmp");
        int[] n = {0};
        try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tmp), "UTF-8"), 1 << 16)) {
            w.write("[");
            walk(root, 0, maxDepth, w, n);
            w.write("]");
        }
        if (out.exists()) out.delete();
        if (!tmp.renameTo(out)) throw new IOException("cannot write index");
        return n[0];
    }

    private static void walk(File dir, int depth, int maxDepth, BufferedWriter w, int[] n) throws IOException {
        File[] list = dir.listFiles();
        if (list == null) return;
        String canon;
        try { canon = dir.getCanonicalPath(); } catch (IOException e) { return; }
        for (File f : list) {
            String name = f.getName();
            if (name.length() == 0 || name.charAt(0) == '.') continue;
            if (f.isDirectory()) {
                if (depth == 0 && name.equals("Android")) continue;
                if (name.equals("lost+found")) continue;
                emit(w, n, f.getAbsolutePath(), 0, f.lastModified(), 1);
                if (depth < maxDepth && !escapes(f, canon)) walk(f, depth + 1, maxDepth, w, n);
            } else {
                emit(w, n, f.getAbsolutePath(), f.length(), f.lastModified(), 0);
            }
        }
    }

    private static void emit(BufferedWriter w, int[] n, String path, long size, long mtime, int dir) throws IOException {
        if (n[0] > 0) w.write(',');
        w.write('[');
        w.write(jstr(path));
        w.write(',');
        w.write(Long.toString(size));
        w.write(',');
        w.write(Long.toString(mtime));
        w.write(',');
        w.write(dir == 1 ? '1' : '0');
        w.write(']');
        n[0]++;
    }

    /** Total size and file count of a folder (or a single file). */
    public static long[] dirSize(File f) {
        long[] r = {0, 0};
        sizeInto(f, r, 0);
        return r;
    }

    private static void sizeInto(File f, long[] r, int depth) {
        if (depth > 40) return;
        if (f.isDirectory()) {
            File[] c = f.listFiles();
            if (c == null) return;
            String canon;
            try { canon = f.getCanonicalPath(); } catch (IOException e) { return; }
            for (File x : c) {
                if (x.isDirectory() && escapes(x, canon)) continue;
                sizeInto(x, r, depth + 1);
            }
        } else {
            r[0] += f.length();
            r[1]++;
        }
    }

    /* ------------------------------------------------------------------ */
    /* duplicate fingerprint                                                */
    /* ------------------------------------------------------------------ */

    /** SHA-1 over size + head/middle/tail samples (whole file when small). */
    public static String fingerprint(File f) throws Exception {
        long len = f.length();
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        md.update(Long.toString(len).getBytes("UTF-8"));
        final int S = 1 << 20;
        byte[] buf = new byte[1 << 16];
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            long[] offs;
            if (len <= 3L * S) offs = new long[]{0};
            else offs = new long[]{0, len / 2 - S / 2, len - S};
            for (long off : offs) {
                r.seek(off);
                long left = len <= 3L * S ? len : S;
                while (left > 0) {
                    int k = r.read(buf, 0, (int) Math.min(buf.length, left));
                    if (k <= 0) break;
                    md.update(buf, 0, k);
                    left -= k;
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    /* ------------------------------------------------------------------ */
    /* ZIP create                                                           */
    /* ------------------------------------------------------------------ */

    private static boolean alreadyCompressed(String e) {
        switch (e) {
            case "jpg": case "jpeg": case "png": case "webp": case "gif": case "heic": case "heif": case "avif":
            case "mp4": case "mkv": case "webm": case "mov": case "3gp": case "avi": case "m4v":
            case "mp3": case "m4a": case "aac": case "ogg": case "opus": case "flac":
            case "zip": case "rar": case "7z": case "gz": case "tgz": case "bz2": case "xz": case "apk":
            case "jar": case "docx": case "xlsx": case "pptx": case "epub": case "pdf":
                return true;
            default:
                return false;
        }
    }

    /**
     * Compresses files/folders into a ZIP. Writes to name.zip.part, then renames to a unique name.
     * Returns the final file.
     */
    public static File zip(List<File> srcs, File dest, Progress p) throws IOException {
        long total = 0;
        for (File s : srcs) total += dirSize(s)[0];
        File parent = dest.getParentFile();
        if (parent != null) parent.mkdirs();
        File tmp = new File(dest.getPath() + ".part");
        Ticker t = new Ticker(p, total);
        Set<String> used = new HashSet<>();
        boolean ok = false;
        try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tmp), 1 << 16))) {
            z.setLevel(Deflater.DEFAULT_COMPRESSION);
            for (File s : srcs) {
                String en = s.getName();
                int c = 1;
                while (used.contains(en)) en = s.getName() + "_" + (c++);
                used.add(en);
                addEntry(z, s, en, t, tmp, dest);
            }
            ok = true;
        } finally {
            if (!ok) tmp.delete();
        }
        File fin = unique(dest);
        if (!tmp.renameTo(fin)) { tmp.delete(); throw new IOException("cannot save zip"); }
        t.finish();
        return fin;
    }

    private static void addEntry(ZipOutputStream z, File f, String entry, Ticker t, File tmp, File dest) throws IOException {
        if (f.equals(tmp) || f.equals(dest)) return;
        if (f.isDirectory()) {
            String en = entry.endsWith("/") ? entry : entry + "/";
            ZipEntry ze = new ZipEntry(en);
            ze.setTime(f.lastModified());
            z.putNextEntry(ze);
            z.closeEntry();
            File[] kids = f.listFiles();
            if (kids == null) return;
            Arrays.sort(kids);
            String canon;
            try { canon = f.getCanonicalPath(); } catch (IOException e) { return; }
            for (File k : kids) {
                if (k.isDirectory() && escapes(k, canon)) continue;
                addEntry(z, k, en + k.getName(), t, tmp, dest);
            }
        } else {
            z.setLevel(alreadyCompressed(ext(f.getName())) ? Deflater.NO_COMPRESSION : Deflater.DEFAULT_COMPRESSION);
            ZipEntry ze = new ZipEntry(entry);
            ze.setTime(f.lastModified());
            z.putNextEntry(ze);
            byte[] buf = new byte[1 << 16];
            try (InputStream in = new FileInputStream(f)) {
                int n;
                t.add(0, f.getName());
                while ((n = in.read(buf)) > 0) {
                    z.write(buf, 0, n);
                    t.add(n, null);
                }
            } catch (Cancelled c) {
                throw c;
            } catch (IOException e) {
                // unreadable file: skip it rather than fail the whole archive
            }
            z.closeEntry();
        }
    }

    /* ------------------------------------------------------------------ */
    /* extract                                                              */
    /* ------------------------------------------------------------------ */

    public static final class Result {
        public File dest;
        public int files;
        public long bytes;
    }

    public static Result extract(File arc, File destRoot, boolean wrap, Progress p) throws IOException {
        String low = arc.getName().toLowerCase(Locale.ROOT);
        if (!canExtract(arc.getName())) throw new IOException("Unsupported archive type");
        File dest = wrap ? unique(new File(destRoot, stem(arc.getName()))) : destRoot;
        if (!dest.exists() && !dest.mkdirs()) throw new IOException("Cannot create folder");
        Result r = new Result();
        r.dest = dest;
        boolean ok = false;
        try {
            if (isZipName(low)) extractZip(arc, dest, p, r);
            else if (isTarGz(low)) extractTarStream(arc, true, dest, p, r);
            else if (isTar(low)) extractTarStream(arc, false, dest, p, r);
            else extractGz(arc, dest, p, r);
            ok = true;
        } finally {
            if (!ok && wrap && r.files == 0) deleteQuiet(dest);
        }
        return r;
    }

    private static void deleteQuiet(File f) {
        File[] k = f.listFiles();
        if (k != null) for (File x : k) deleteQuiet(x);
        f.delete();
    }

    private static ZipFile openZip(File f) throws IOException {
        try {
            return new ZipFile(f, Charset.forName("UTF-8"));
        } catch (IllegalArgumentException | java.util.zip.ZipException e) {
            return new ZipFile(f, Charset.forName("ISO-8859-1"));
        }
    }

    /** Resolves an archive entry name inside dest; returns null for unsafe (zip-slip) names. */
    private static File safe(File dest, String name) throws IOException {
        name = name.replace('\\', '/');
        while (name.startsWith("/")) name = name.substring(1);
        if (name.length() == 0) return null;
        File out = new File(dest, name);
        String base = dest.getCanonicalPath() + File.separator;
        String target = out.getCanonicalPath();
        if (!(target + File.separator).startsWith(base)) return null;
        return out;
    }

    private static void extractZip(File arc, File dest, Progress p, Result r) throws IOException {
        try (ZipFile zf = openZip(arc)) {
            long total = 0;
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (!e.isDirectory() && e.getSize() > 0) total += e.getSize();
            }
            Ticker t = new Ticker(p, total);
            en = zf.entries();
            byte[] buf = new byte[1 << 16];
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                File out = safe(dest, e.getName());
                if (out == null) continue;
                if (e.isDirectory()) { out.mkdirs(); continue; }
                File par = out.getParentFile();
                if (par != null && !par.exists()) par.mkdirs();
                if (par != null && !par.isDirectory()) continue;
                if (out.exists()) out = unique(out);
                t.add(0, out.getName());
                try (InputStream in = zf.getInputStream(e); OutputStream os = new BufferedOutputStream(new FileOutputStream(out), 1 << 16)) {
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        os.write(buf, 0, n);
                        r.bytes += n;
                        t.add(n, null);
                    }
                } catch (Cancelled c) {
                    out.delete();
                    throw c;
                } catch (IOException ex) {
                    out.delete();
                    throw new IOException("Could not read \"" + e.getName() + "\" (password-protected or damaged archive?)");
                }
                if (e.getTime() > 0) out.setLastModified(e.getTime());
                r.files++;
            }
            t.finish();
        }
    }

    private static void extractGz(File arc, File dest, Progress p, Result r) throws IOException {
        String nm = arc.getName();
        String out = nm.substring(0, nm.length() - 3);
        if (out.length() == 0) out = "extracted";
        File of = unique(new File(dest, out));
        Ticker t = new Ticker(p, arc.length());
        byte[] buf = new byte[1 << 16];
        try (CountingIn raw = new CountingIn(new FileInputStream(arc));
             GZIPInputStream gz = new GZIPInputStream(raw, 1 << 16);
             OutputStream os = new BufferedOutputStream(new FileOutputStream(of), 1 << 16)) {
            int n;
            long seen = 0;
            t.add(0, of.getName());
            while ((n = gz.read(buf)) > 0) {
                os.write(buf, 0, n);
                r.bytes += n;
                long c = raw.count;
                t.add(c - seen, null);
                seen = c;
            }
        } catch (Cancelled c) {
            of.delete();
            throw c;
        }
        r.files = 1;
        t.finish();
    }

    private static final class CountingIn extends FilterInputStream {
        long count;
        CountingIn(InputStream in) { super(in); }
        @Override public int read() throws IOException { int b = super.read(); if (b >= 0) count++; return b; }
        @Override public int read(byte[] b, int o, int l) throws IOException { int n = super.read(b, o, l); if (n > 0) count += n; return n; }
    }

    /* ---------- tar ---------- */

    private static boolean readFully(InputStream in, byte[] b, int len) throws IOException {
        int o = 0;
        while (o < len) {
            int n = in.read(b, o, len - o);
            if (n < 0) return o > 0 && false;
            o += n;
        }
        return true;
    }

    private static void skipFully(InputStream in, long n) throws IOException {
        byte[] sink = new byte[1 << 13];
        while (n > 0) {
            long s = in.skip(n);
            if (s <= 0) {
                int k = in.read(sink, 0, (int) Math.min(sink.length, n));
                if (k < 0) return;
                s = k;
            }
            n -= s;
        }
    }

    private static String cstr(byte[] b, int off, int len) {
        int e = off;
        while (e < off + len && b[e] != 0) e++;
        try { return new String(b, off, e - off, "UTF-8"); } catch (Exception x) { return ""; }
    }

    private static long octal(byte[] b, int off, int len) {
        // GNU base-256 for huge sizes
        if ((b[off] & 0x80) != 0) {
            long v = 0;
            for (int i = 1; i < len; i++) v = (v << 8) | (b[off + i] & 0xff);
            return v;
        }
        long v = 0;
        for (int i = off; i < off + len; i++) {
            int c = b[i];
            if (c == 0 || c == ' ') { if (v == 0 && c == ' ') continue; if (c == 0) break; else break; }
            if (c < '0' || c > '7') break;
            v = (v << 3) + (c - '0');
        }
        return v;
    }

    private static boolean zeroBlock(byte[] b) {
        for (int i = 0; i < 512; i++) if (b[i] != 0) return false;
        return true;
    }

    /** One parsed tar header. */
    private static final class TarHead { String name; long size; char type; }

    /** Reads the next real header (resolving GNU long names and PAX paths). Returns null at the end. */
    private static TarHead nextHead(InputStream in, byte[] h) throws IOException {
        String longName = null;
        while (true) {
            if (!readFully(in, h, 512)) return null;
            if (zeroBlock(h)) return null;
            String name = cstr(h, 0, 100);
            long size = octal(h, 124, 12);
            char type = (char) (h[156] & 0xff);
            String magic = cstr(h, 257, 5);
            if ("ustar".equals(magic)) {
                String prefix = cstr(h, 345, 155);
                if (prefix.length() > 0) name = prefix + "/" + name;
            }
            if (type == 'L') {
                byte[] nb = new byte[(int) size];
                readFully(in, nb, nb.length);
                skipFully(in, (512 - size % 512) % 512);
                longName = cstr(nb, 0, nb.length);
                continue;
            }
            if (type == 'x' || type == 'g') {
                byte[] pb = new byte[(int) size];
                readFully(in, pb, pb.length);
                skipFully(in, (512 - size % 512) % 512);
                if (type == 'x') {
                    String s;
                    try { s = new String(pb, "UTF-8"); } catch (Exception e) { s = ""; }
                    int i = s.indexOf(" path=");
                    if (i >= 0) {
                        int e = s.indexOf('\n', i);
                        if (e > i) longName = s.substring(i + 6, e);
                    }
                }
                continue;
            }
            TarHead th = new TarHead();
            th.name = longName != null ? longName : name;
            th.size = size;
            th.type = type;
            return th;
        }
    }

    private static InputStream openTar(File arc, boolean gz, CountingIn[] holder) throws IOException {
        CountingIn raw = new CountingIn(new FileInputStream(arc));
        holder[0] = raw;
        return gz ? new GZIPInputStream(raw, 1 << 16) : raw;
    }

    private static void extractTarStream(File arc, boolean gz, File dest, Progress p, Result r) throws IOException {
        CountingIn[] holder = new CountingIn[1];
        Ticker t = new Ticker(p, arc.length());
        byte[] h = new byte[512];
        byte[] buf = new byte[1 << 16];
        try (InputStream in = openTar(arc, gz, holder)) {
            long seen = 0;
            TarHead th;
            while ((th = nextHead(in, h)) != null) {
                boolean file = th.type == '0' || th.type == 0 || th.type == '7';
                boolean dir = th.type == '5';
                File out = (file || dir) ? safe(dest, th.name) : null;
                long remain = th.size;
                if (out != null && dir) {
                    out.mkdirs();
                } else if (out != null && file) {
                    File par = out.getParentFile();
                    if (par != null && !par.exists()) par.mkdirs();
                    if (out.exists()) out = unique(out);
                    t.add(0, out.getName());
                    try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out), 1 << 16)) {
                        while (remain > 0) {
                            int k = in.read(buf, 0, (int) Math.min(buf.length, remain));
                            if (k < 0) throw new IOException("Archive is truncated");
                            os.write(buf, 0, k);
                            remain -= k;
                            r.bytes += k;
                            long c = holder[0].count;
                            t.add(c - seen, null);
                            seen = c;
                        }
                    } catch (Cancelled c) {
                        out.delete();
                        throw c;
                    }
                    r.files++;
                }
                if (remain > 0) skipFully(in, remain);
                skipFully(in, (512 - th.size % 512) % 512);
            }
        }
        t.finish();
    }

    /* ------------------------------------------------------------------ */
    /* archive listing                                                      */
    /* ------------------------------------------------------------------ */

    public static final class Entry {
        public final String name; public final long size; public final boolean dir;
        Entry(String n, long s, boolean d) { name = n; size = s; dir = d; }
    }

    public static final class Listing {
        public final List<Entry> entries = new ArrayList<>();
        public int total;
        public long bytes;
    }

    public static Listing list(File arc, int max) throws IOException {
        String low = arc.getName().toLowerCase(Locale.ROOT);
        Listing L = new Listing();
        if (isZipName(low)) {
            try (ZipFile zf = openZip(arc)) {
                Enumeration<? extends ZipEntry> en = zf.entries();
                while (en.hasMoreElements()) {
                    ZipEntry e = en.nextElement();
                    L.total++;
                    if (!e.isDirectory() && e.getSize() > 0) L.bytes += e.getSize();
                    if (L.entries.size() < max) L.entries.add(new Entry(e.getName(), Math.max(0, e.getSize()), e.isDirectory()));
                }
            }
        } else if (isTarGz(low) || isTar(low)) {
            CountingIn[] holder = new CountingIn[1];
            byte[] h = new byte[512];
            try (InputStream in = openTar(arc, isTarGz(low), holder)) {
                TarHead th;
                while ((th = nextHead(in, h)) != null) {
                    boolean dir = th.type == '5';
                    boolean file = th.type == '0' || th.type == 0 || th.type == '7';
                    if (file || dir) {
                        L.total++;
                        if (file) L.bytes += th.size;
                        if (L.entries.size() < max) L.entries.add(new Entry(th.name, th.size, dir));
                    }
                    skipFully(in, th.size + (512 - th.size % 512) % 512);
                }
            }
        } else if (isGz(low)) {
            String nm = arc.getName();
            L.entries.add(new Entry(nm.substring(0, nm.length() - 3), 0, false));
            L.total = 1;
        } else {
            throw new IOException("Unsupported archive type");
        }
        return L;
    }
}


/* ======================================================================
 * FzNet — phone-to-phone transfer over the local network (Wi-Fi or hotspot).
 * Pure Java sockets: a receiver listens, a sender finds it (subnet scan or IP),
 * the receiver must ACCEPT, then raw bytes stream with live progress.
 * ====================================================================== */
final class FzNet {
    private FzNet() {}

    static final int PORT = 48620;
    static final int VERSION = 1;
    private static final byte[] MAGIC = {'F', 'Z', 'N', '1'};

    static final class Item {
        final File file; final String rel; final long size;
        Item(File f, String rel) { this.file = f; this.rel = rel; this.size = f.length(); }
    }

    static final class Offered {
        final String rel; final long size;
        Offered(String rel, long size) { this.rel = rel; this.size = size; }
    }

    /** Lets the UI cancel a running send / scan. */
    static final class Token {
        volatile boolean cancelled;
        volatile Socket socket;
        void cancel() {
            cancelled = true;
            Socket s = socket;
            if (s != null) { try { s.close(); } catch (IOException ignored) {} }
        }
    }

    abstract static class Listener {
        void onOffer(String id, String sender, String ip, List<Offered> files, long total, String code) {}
        void onCode(String id, String code) {}
        void onProgress(String id, String role, long done, long total, String name, double bps, int fileIdx, int fileCount) {}
        void onDone(String id, String role, boolean ok, int count, long bytes, String dest, String error) {}
        void onPeer(String ip, int port, String name) {}
    }

    /* ---------- helpers ---------- */

    private static ThreadFactory daemons(final String name) {
        return new ThreadFactory() {
            int n = 0;
            @Override public Thread newThread(Runnable r) {
                Thread t = new Thread(r, name + "-" + (n++));
                t.setDaemon(true);
                return t;
            }
        };
    }

    static String code(int nonce, int count, long total) {
        int v = nonce * 31 + count * 17 + (int) (total % 9973);
        return String.format("%04d", Math.floorMod(v, 10000));
    }

    /** Makes a path received from the network safe: no "..", no absolute paths, no illegal characters. */
    static String sanitize(String rel) {
        StringBuilder out = new StringBuilder();
        for (String seg : rel.replace('\\', '/').split("/")) {
            if (seg.isEmpty() || seg.equals(".") || seg.equals("..")) continue;
            String c = seg.replaceAll("[\\\\:*?\"<>|\\u0000-\\u001f]", "_").trim();
            if (c.isEmpty()) c = "_";
            if (c.length() > 120) c = c.substring(0, 120);
            if (out.length() > 0) out.append('/');
            out.append(c);
        }
        return out.length() == 0 ? "file" : out.toString();
    }

    private static String friendly(Throwable e) {
        if (e instanceof ConnectException) return "Couldn't reach that phone. Is it on Receive and on the same Wi-Fi?";
        if (e instanceof SocketTimeoutException) return "The other phone didn't respond";
        if (e instanceof EOFException) return "Connection closed";
        if (e instanceof SecurityException) return "Network permission missing for this build";
        String m = e.getMessage();
        if (m != null && m.contains("Permission denied")) return "Network permission missing for this build";
        if (m != null && (m.contains("reset") || m.contains("Broken pipe") || m.contains("closed"))) return "Connection lost";
        return m == null || m.isEmpty() ? e.getClass().getSimpleName() : m;
    }

    /** This phone's IPv4 addresses on Wi-Fi / hotspot / ethernet: [ip, interface]. */
    static List<String[]> localAddrs() {
        List<String[]> out = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                try {
                    if (!ni.isUp() || ni.isLoopback()) continue;
                } catch (Exception e) { continue; }
                String n = ni.getName().toLowerCase(Locale.ROOT);
                if (n.startsWith("rmnet") || n.startsWith("tun") || n.startsWith("ppp") || n.startsWith("dummy") || n.startsWith("v4-")) continue;
                Enumeration<InetAddress> ads = ni.getInetAddresses();
                while (ads.hasMoreElements()) {
                    InetAddress a = ads.nextElement();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress() && !a.isLinkLocalAddress())
                        out.add(new String[]{a.getHostAddress(), ni.getName()});
                }
            }
        } catch (Exception ignored) {}
        return out;
    }

    /* ---------- progress meter (throttled, with smoothed speed) ---------- */

    private static final class Meter {
        final Listener ln; final String id, role; final long total; final int fileCount;
        long done, lastDone, lastEmit; long lastT = System.nanoTime(); double bps; String name = ""; int idx;
        Meter(Listener ln, String id, String role, long total, int fileCount) {
            this.ln = ln; this.id = id; this.role = role; this.total = total; this.fileCount = fileCount;
        }
        void add(long n, String nm, int fi) {
            done += n; name = nm; idx = fi;
            long now = System.nanoTime();
            if (now - lastEmit >= 120_000_000L) emit(now);
        }
        void emit(long now) {
            double dt = (now - lastT) / 1e9;
            if (dt > 0.001) {
                double inst = (done - lastDone) / dt;
                bps = bps == 0 ? inst : bps * 0.7 + inst * 0.3;
                lastT = now; lastDone = done;
            }
            lastEmit = now;
            ln.onProgress(id, role, done, total, name, bps, idx, fileCount);
        }
        void flush() { emit(System.nanoTime()); }
    }

    /* ---------- discovery ---------- */

    /** Asks a host whether it is a FileZen receiver. Returns its device name or null. */
    static String probe(String host, int port, int timeoutMs) {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(host, port), timeoutMs);
            s.setSoTimeout(timeoutMs * 3 + 400);
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
            out.write(MAGIC); out.writeByte('H'); out.flush();
            DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream()));
            byte[] m = new byte[4];
            in.readFully(m);
            if (!Arrays.equals(m, MAGIC)) return null;
            String name = in.readUTF();
            in.readInt();
            return name;
        } catch (Exception e) {
            return null;
        } finally {
            try { s.close(); } catch (IOException ignored) {}
        }
    }

    /** Sweeps the /24 of every local address. Calls onPeer for each receiver found. Returns the count. */
    static int scan(final int port, final int timeoutMs, final Listener ln, final Token tk) {
        final Set<String> own = new HashSet<>();
        final List<String> hosts = new ArrayList<>();
        List<String[]> mine = localAddrs();
        for (String[] a : mine) own.add(a[0]);
        for (String[] a : mine) {
            String[] p = a[0].split("\\.");
            if (p.length != 4) continue;
            String base = p[0] + "." + p[1] + "." + p[2] + ".";
            for (int i = 1; i <= 254; i++) {
                String h = base + i;
                if (!own.contains(h) && !hosts.contains(h)) hosts.add(h);
            }
        }
        return scanHosts(hosts, port, timeoutMs, ln, tk);
    }

    static int scanHosts(List<String> hosts, final int port, final int timeoutMs, final Listener ln, final Token tk) {
        final AtomicInteger found = new AtomicInteger();
        ExecutorService ex = Executors.newFixedThreadPool(64, daemons("fz-scan"));
        for (final String h : hosts) {
            ex.execute(new Runnable() {
                @Override public void run() {
                    if (tk != null && tk.cancelled) return;
                    String nm = probe(h, port, timeoutMs);
                    if (nm != null) { found.incrementAndGet(); ln.onPeer(h, port, nm); }
                }
            });
        }
        ex.shutdown();
        try { ex.awaitTermination(9, TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
        ex.shutdownNow();
        return found.get();
    }

    /* ---------- receiver ---------- */

    static final class Receiver {
        private final String name; private final File dest; private final Listener ln;
        private volatile ServerSocket server; private volatile boolean running;
        private final Map<String, Session> sessions = new ConcurrentHashMap<>();
        private final ExecutorService pool = Executors.newCachedThreadPool(daemons("fz-recv"));

        private static final class Session {
            final String id; final Socket sock; final CountDownLatch latch = new CountDownLatch(1);
            volatile int accepted = -1; volatile boolean cancelled;
            Session(String id, Socket s) { this.id = id; this.sock = s; }
        }

        Receiver(String name, File dest, Listener ln) { this.name = name; this.dest = dest; this.ln = ln; }

        int start(int port) throws IOException {
            ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(port));
            server = ss; running = true;
            pool.execute(new Runnable() { @Override public void run() { acceptLoop(); } });
            return ss.getLocalPort();
        }

        boolean isRunning() { return running; }

        void stop() {
            running = false;
            ServerSocket ss = server;
            if (ss != null) { try { ss.close(); } catch (IOException ignored) {} }
            for (Session s : sessions.values()) {
                s.cancelled = true; s.latch.countDown();
                try { s.sock.close(); } catch (IOException ignored) {}
            }
            pool.shutdownNow();
        }

        void answer(String id, boolean accept) {
            Session s = sessions.get(id);
            if (s != null) { s.accepted = accept ? 1 : 0; s.latch.countDown(); }
        }

        void cancel(String id) {
            Session s = sessions.get(id);
            if (s != null) { s.cancelled = true; s.latch.countDown(); try { s.sock.close(); } catch (IOException ignored) {} }
        }

        private void acceptLoop() {
            while (running) {
                try {
                    final Socket s = server.accept();
                    pool.execute(new Runnable() { @Override public void run() { handle(s); } });
                } catch (IOException e) {
                    if (!running) return;
                }
            }
        }

        private void handle(Socket s) {
            String id = null;
            try {
                s.setTcpNoDelay(true);
                s.setReceiveBufferSize(1 << 18);
                s.setSoTimeout(15000);
                DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 1 << 16));
                DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream(), 1 << 14));
                byte[] m = new byte[4];
                in.readFully(m);
                if (!Arrays.equals(m, MAGIC)) return;
                int op = in.readUnsignedByte();
                if (op == 'H') {
                    out.write(MAGIC); out.writeUTF(name); out.writeInt(VERSION); out.flush();
                    return;
                }
                if (op != 'O') return;
                String sender = in.readUTF();
                int count = in.readInt();
                long total = in.readLong();
                if (count < 0 || count > 200000 || total < 0) return;
                final List<Offered> files = new ArrayList<>();
                long sum = 0;
                for (int i = 0; i < count; i++) {
                    String rel = in.readUTF(); long sz = in.readLong();
                    if (sz < 0) return;
                    files.add(new Offered(sanitize(rel), sz)); sum += sz;
                }
                int nonce = in.readInt();
                if (sum != total) return;
                id = UUID.randomUUID().toString().substring(0, 8);
                Session se = new Session(id, s);
                sessions.put(id, se);
                String ip = s.getInetAddress() == null ? "" : s.getInetAddress().getHostAddress();
                if (!dest.exists()) dest.mkdirs();
                if (dest.getUsableSpace() < total + (8L << 20)) {
                    out.writeByte(0); out.flush();
                    ln.onDone(id, "recv", false, 0, 0, null, "Not enough free space");
                    return;
                }
                ln.onOffer(id, sender, ip, files, total, code(nonce, count, total));
                boolean ok = false;
                try { ok = se.latch.await(120, TimeUnit.SECONDS) && se.accepted == 1 && !se.cancelled; } catch (InterruptedException ignored) {}
                out.writeByte(ok ? 1 : 0); out.flush();
                if (!ok) { ln.onDone(id, "recv", false, 0, 0, null, se.cancelled ? "Cancelled" : "Declined"); return; }
                s.setSoTimeout(30000);
                if (!dest.exists()) dest.mkdirs();
                Meter meter = new Meter(ln, id, "recv", total, count);
                Map<String, String> top = new HashMap<>();
                byte[] buf = new byte[1 << 16];
                long got = 0; int n = 0;
                File current = null;
                try {
                    for (int i = 0; i < files.size(); i++) {
                        Offered f = files.get(i);
                        String[] seg = f.rel.split("/", 2);
                        String mapped = top.get(seg[0]);
                        if (mapped == null) {
                            File want = new File(dest, seg[0]);
                            mapped = FzCore.unique(want).getName();
                            top.put(seg[0], mapped);
                        }
                        File out2 = seg.length > 1 ? new File(new File(dest, mapped), seg[1]) : new File(dest, mapped);
                        File par = out2.getParentFile();
                        if (par != null && !par.exists()) par.mkdirs();
                        current = out2;
                        long left = f.size;
                        meter.add(0, out2.getName(), i);
                        OutputStream fo = new BufferedOutputStream(new FileOutputStream(out2), 1 << 16);
                        try {
                            while (left > 0) {
                                int r = in.read(buf, 0, (int) Math.min(buf.length, left));
                                if (r < 0) throw new EOFException();
                                fo.write(buf, 0, r);
                                left -= r; got += r;
                                meter.add(r, out2.getName(), i);
                            }
                        } finally { fo.close(); }
                        current = null; n++;
                        if (f.size == 0) meter.add(0, out2.getName(), i);
                    }
                    meter.flush();
                    out.writeByte('D'); out.writeInt(n); out.flush();
                    ln.onDone(id, "recv", true, n, got, dest.getAbsolutePath(), null);
                } catch (IOException e) {
                    if (current != null) current.delete();
                    ln.onDone(id, "recv", false, n, got, dest.getAbsolutePath(), se.cancelled ? "Cancelled" : friendly(e));
                }
            } catch (IOException e) {
                if (id != null) ln.onDone(id, "recv", false, 0, 0, null, friendly(e));
            } finally {
                if (id != null) sessions.remove(id);
                try { s.close(); } catch (IOException ignored) {}
            }
        }
    }

    /* ---------- sender ---------- */

    static void send(String host, int port, String myName, List<Item> items, String id, Listener ln, Token tk) {
        long total = 0;
        for (Item it : items) total += it.size;
        Socket s = new Socket();
        tk.socket = s;
        int sent = 0; long bytes = 0;
        try {
            s.setTcpNoDelay(true);
            s.setSendBufferSize(1 << 18);
            s.connect(new InetSocketAddress(host, port), 6000);
            s.setSoTimeout(135000);
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(s.getOutputStream(), 1 << 16));
            DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 1 << 14));
            int nonce = new Random().nextInt();
            out.write(MAGIC); out.writeByte('O');
            out.writeUTF(myName); out.writeInt(items.size()); out.writeLong(total);
            for (Item it : items) { out.writeUTF(it.rel); out.writeLong(it.size); }
            out.writeInt(nonce);
            out.flush();
            ln.onCode(id, code(nonce, items.size(), total));
            int ans = in.readUnsignedByte();
            if (ans != 1) { ln.onDone(id, "send", false, 0, 0, null, tk.cancelled ? "Cancelled" : "Declined by the other phone"); return; }
            s.setSoTimeout(60000);
            Meter meter = new Meter(ln, id, "send", total, items.size());
            byte[] buf = new byte[1 << 16];
            for (int i = 0; i < items.size(); i++) {
                Item it = items.get(i);
                long left = it.size;
                meter.add(0, it.file.getName(), i);
                InputStream fi = new FileInputStream(it.file);
                try {
                    while (left > 0) {
                        if (tk.cancelled) throw new IOException("Cancelled");
                        int r = fi.read(buf, 0, (int) Math.min(buf.length, left));
                        if (r < 0) throw new IOException("\"" + it.file.getName() + "\" changed while sending");
                        out.write(buf, 0, r);
                        left -= r; bytes += r;
                        meter.add(r, it.file.getName(), i);
                    }
                } finally { fi.close(); }
                sent++;
            }
            out.flush();
            meter.flush();
            int ack = in.readUnsignedByte();
            if (ack != 'D') throw new IOException("The other phone didn't confirm");
            ln.onDone(id, "send", true, sent, bytes, null, null);
        } catch (IOException e) {
            ln.onDone(id, "send", false, sent, bytes, null, tk.cancelled ? "Cancelled" : friendly(e));
        } finally {
            try { s.close(); } catch (IOException ignored) {}
        }
    }

    /** Expands files and folders into transferable items with relative names (folders keep their structure). */
    static List<Item> expand(List<File> roots, List<String> names) {
        List<Item> out = new ArrayList<>();
        for (int i = 0; i < roots.size(); i++) {
            File f = roots.get(i);
            String nm = names != null && i < names.size() && names.get(i) != null && !names.get(i).isEmpty() ? names.get(i) : f.getName();
            walk(f, nm, out, 0);
        }
        return out;
    }

    private static void walk(File f, String rel, List<Item> out, int depth) {
        if (depth > 30 || out.size() > 200000) return;
        if (f.isDirectory()) {
            File[] k = f.listFiles();
            if (k == null) return;
            Arrays.sort(k);
            for (File c : k) {
                if (c.getName().startsWith(".")) continue;
                walk(c, rel + "/" + c.getName(), out, depth + 1);
            }
        } else if (f.isFile() && f.canRead()) {
            out.add(new Item(f, rel));
        }
    }
}
