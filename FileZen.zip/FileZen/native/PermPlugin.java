package com.filezen.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.zip.Deflater;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * FileZen native engine (one Capacitor plugin).
 *
 * Imports nothing outside the Android framework and Capacitor core. FileProvider is reached
 * through reflection so the app still compiles without androidx.core on the classpath.
 * Every heavy call runs on its own thread pool so the UI bridge never blocks, and every
 * failure becomes a rejected promise instead of a crash.
 */
@CapacitorPlugin(name = "Perm")
public class PermPlugin extends Plugin {

    private static ExecutorService pool(final String name, int n) {
        return Executors.newFixedThreadPool(n, new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, name);
                t.setDaemon(true);
                t.setPriority(Thread.NORM_PRIORITY - 1);
                return t;
            }
        });
    }

    private final ExecutorService listPool = pool("fz-list", 2);
    private final ExecutorService idxPool = pool("fz-index", 1);
    private final ExecutorService thumbPool = pool("fz-thumb", 3);
    private final ExecutorService prevPool = pool("fz-preview", 1);
    private final ExecutorService ioPool = pool("fz-io", 2);
    private final ConcurrentHashMap<String, Boolean> cancels = new ConcurrentHashMap<String, Boolean>();

    private static String msg(Throwable e) {
        String m = e.getMessage();
        return m == null || m.length() == 0 ? e.getClass().getSimpleName() : m;
    }

    private static List<String> strings(JSArray a) {
        List<String> out = new ArrayList<String>();
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            try {
                String s = a.getString(i);
                if (s != null) out.add(s);
            } catch (Exception ignored) {}
        }
        return out;
    }

    /* ---------- storage permission + totals ---------- */

    @PluginMethod
    public void check(PluginCall call) {
        JSObject o = new JSObject();
        boolean granted = Build.VERSION.SDK_INT >= 30 ? Environment.isExternalStorageManager() : true;
        long total = 0L;
        long free = 0L;
        try {
            StatFs s = new StatFs(Environment.getExternalStorageDirectory().getPath());
            total = s.getTotalBytes();
            free = s.getAvailableBytes();
        } catch (Exception ignored) {}
        o.put("granted", granted);
        o.put("total", total);
        o.put("free", free);
        call.resolve(o);
    }

    @PluginMethod
    public void request(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            }
        } catch (Exception ignored) {}
        call.resolve();
    }

    /* ---------- status / navigation bar colours ---------- */

    @PluginMethod
    public void setBars(PluginCall call) {
        final String status = call.getString("status", "#0B0B0D");
        final String nav = call.getString("nav", "#0B0B0D");
        final boolean lightIcons = Boolean.TRUE.equals(call.getBoolean("light", Boolean.FALSE));
        if (getActivity() == null) {
            call.resolve();
            return;
        }
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Window w = getActivity().getWindow();
                    w.setStatusBarColor(Color.parseColor(status));
                    w.setNavigationBarColor(Color.parseColor(nav));
                    View dv = w.getDecorView();
                    int flags = dv.getSystemUiVisibility();
                    if (lightIcons) {
                        flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    } else {
                        flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    }
                    dv.setSystemUiVisibility(flags);
                } catch (Exception ignored) {}
            }
        });
        call.resolve();
    }

    /* ---------- fast directory listing (one call, no per-file bridge cost) ---------- */

    @PluginMethod
    public void list(final PluginCall call) {
        final String path = call.getString("path");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        listPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    File[] fs = new File(path).listFiles();
                    if (fs == null) {
                        call.reject("cannot read folder");
                        return;
                    }
                    JSArray arr = new JSArray();
                    for (File f : fs) {
                        JSObject o = new JSObject();
                        boolean d = f.isDirectory();
                        o.put("name", f.getName());
                        o.put("type", d ? "directory" : "file");
                        o.put("size", d ? 0L : f.length());
                        o.put("mtime", f.lastModified());
                        arr.put(o);
                    }
                    JSObject r = new JSObject();
                    r.put("files", arr);
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        });
    }

    /* ---------- whole-storage index (written to a file, read back by the WebView) ---------- */

    @PluginMethod
    public void index(final PluginCall call) {
        idxPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    File out = new File(getContext().getCacheDir(), "fzidx.json");
                    int n = FzCore.index(Environment.getExternalStorageDirectory(), out, 20);
                    JSObject r = new JSObject();
                    r.put("path", out.getAbsolutePath());
                    r.put("count", n);
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        });
    }

    @PluginMethod
    public void dirSize(final PluginCall call) {
        final String path = call.getString("path");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    long[] s = FzCore.dirSize(new File(path));
                    JSObject r = new JSObject();
                    r.put("size", s[0]);
                    r.put("count", s[1]);
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        });
    }

    @PluginMethod
    public void hash(final PluginCall call) {
        final List<String> paths = strings(call.getArray("paths"));
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                JSArray out = new JSArray();
                for (String p : paths) {
                    String h = "";
                    try { h = FzCore.fingerprint(new File(p)); } catch (Throwable ignored) {}
                    out.put(h);
                }
                JSObject r = new JSObject();
                r.put("hashes", out);
                call.resolve(r);
            }
        });
    }

    /* ---------- media scanner (keeps Gallery in sync after file changes) ---------- */

    @PluginMethod
    public void scan(PluginCall call) {
        final List<String> l = strings(call.getArray("paths"));
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    List<String> out = new ArrayList<String>();
                    for (String p : l) expand(new File(p), out, 0);
                    if (!out.isEmpty()) {
                        MediaScannerConnection.scanFile(getContext(), out.toArray(new String[0]), null, null);
                    }
                } catch (Throwable ignored) {}
            }
        });
        call.resolve();
    }

    /** Folders expand to their files; missing paths are passed through so stale Gallery entries get removed. */
    private static void expand(File f, List<String> out, int depth) {
        if (out.size() > 3000 || depth > 12) return;
        if (f.isDirectory()) {
            File[] k = f.listFiles();
            if (k != null) for (File x : k) expand(x, out, depth + 1);
        } else {
            out.add(f.getAbsolutePath());
        }
    }

    /* ---------- thumbnails ---------- */

    private File thumbDir() {
        File d = new File(getContext().getCacheDir(), "fzt");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static String sha1(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] b = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 10; i++) sb.append(String.format("%02x", b[i]));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(s.hashCode());
        }
    }

    private static String ext(String n) {
        int i = n.lastIndexOf('.');
        return i > 0 ? n.substring(i + 1).toLowerCase(Locale.ROOT) : "";
    }

    private static boolean in(String e, String... a) {
        for (String x : a) if (x.equals(e)) return true;
        return false;
    }

    /** Decodes with a power-of-two sample so the short (crop) or long (fit) side stays >= target. */
    private static Bitmap decode(String path, byte[] bytes, int target, boolean fit) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        if (bytes != null) BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o);
        else BitmapFactory.decodeFile(path, o);
        if (o.outWidth <= 0 || o.outHeight <= 0) return null;
        int side = fit ? Math.max(o.outWidth, o.outHeight) : Math.min(o.outWidth, o.outHeight);
        int s = 1;
        while (side / (s * 2) >= target) s *= 2;
        BitmapFactory.Options d = new BitmapFactory.Options();
        d.inSampleSize = s;
        d.inPreferredConfig = Bitmap.Config.ARGB_8888;
        if (bytes != null) return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, d);
        return BitmapFactory.decodeFile(path, d);
    }

    private static Bitmap rotate(Bitmap b, String path) {
        try {
            String e = ext(path);
            if (!in(e, "jpg", "jpeg", "heic", "heif")) return b;
            ExifInterface ex = new ExifInterface(path);
            int o = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            int deg = 0;
            if (o == ExifInterface.ORIENTATION_ROTATE_90) deg = 90;
            else if (o == ExifInterface.ORIENTATION_ROTATE_180) deg = 180;
            else if (o == ExifInterface.ORIENTATION_ROTATE_270) deg = 270;
            if (deg == 0) return b;
            Matrix m = new Matrix();
            m.postRotate(deg);
            Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            if (r != b) b.recycle();
            return r;
        } catch (Throwable t) {
            return b;
        }
    }

    private static Bitmap square(Bitmap src, int px) {
        int w = src.getWidth(), h = src.getHeight();
        int s = Math.min(w, h);
        Bitmap c = Bitmap.createBitmap(src, (w - s) / 2, (h - s) / 2, s, s);
        Bitmap r = c.getWidth() == px ? c : Bitmap.createScaledBitmap(c, px, px, true);
        if (c != r && c != src) c.recycle();
        if (r != src) src.recycle();
        return r;
    }

    private static Bitmap fitTo(Bitmap src, int px) {
        int w = src.getWidth(), h = src.getHeight();
        int m = Math.max(w, h);
        if (m <= px) return src;
        float k = (float) px / m;
        Bitmap r = Bitmap.createScaledBitmap(src, Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k)), true);
        if (r != src) src.recycle();
        return r;
    }

    private Bitmap apkIcon(String path, int px) {
        try {
            PackageManager pm = getContext().getPackageManager();
            PackageInfo pi = pm.getPackageArchiveInfo(path, 0);
            if (pi == null || pi.applicationInfo == null) return null;
            ApplicationInfo ai = pi.applicationInfo;
            ai.sourceDir = path;
            ai.publicSourceDir = path;
            Drawable d = ai.loadIcon(pm);
            if (d == null) return null;
            Bitmap b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            d.setBounds(0, 0, px, px);
            d.draw(c);
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    private Bitmap makeThumb(String path, int px, boolean fit) {
        String e = ext(path);
        Bitmap b = null;
        if (in(e, "jpg", "jpeg", "png", "webp", "bmp", "gif", "heic", "heif", "avif")) {
            b = decode(path, null, px, fit);
            if (b != null) b = rotate(b, path);
        } else if (in(e, "mp4", "mkv", "webm", "3gp", "avi", "mov", "m4v", "flv", "ts")) {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(path);
                b = r.getFrameAtTime(1000000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                if (b == null) b = r.getFrameAtTime();
            } catch (Throwable t) {
                b = null;
            } finally {
                try { r.release(); } catch (Throwable ignored) {}
            }
        } else if (in(e, "apk", "xapk", "apks")) {
            b = apkIcon(path, px);
            return b;
        } else if (in(e, "mp3", "m4a", "flac", "ogg", "aac", "opus", "wav", "amr", "wma")) {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(path);
                byte[] art = r.getEmbeddedPicture();
                if (art != null) b = decode(null, art, px, fit);
            } catch (Throwable t) {
                b = null;
            } finally {
                try { r.release(); } catch (Throwable ignored) {}
            }
        }
        if (b == null) return null;
        return fit ? fitTo(b, px) : square(b, px);
    }

    @PluginMethod
    public void thumb(final PluginCall call) {
        final String path = call.getString("path");
        Integer sz = call.getInt("size", 200);
        final int px = Math.max(48, Math.min(2048, sz == null ? 200 : sz));
        final boolean fit = Boolean.TRUE.equals(call.getBoolean("fit", Boolean.FALSE));
        final boolean prio = Boolean.TRUE.equals(call.getBoolean("prio", Boolean.FALSE));
        if (path == null) {
            call.reject("path is required");
            return;
        }
        Runnable job = new Runnable() {
            @Override
            public void run() {
                try {
                    File src = new File(path);
                    if (!src.exists()) {
                        call.reject("missing");
                        return;
                    }
                    boolean png = in(ext(path), "apk", "xapk", "apks");
                    String key = sha1(path + "|" + src.lastModified() + "|" + src.length() + "|" + px + (fit ? "f" : "c"));
                    File out = new File(thumbDir(), key + (png ? ".png" : ".jpg"));
                    if (!out.exists() || out.length() == 0) {
                        Bitmap b = makeThumb(path, px, fit);
                        if (b == null) {
                            call.reject("no thumbnail");
                            return;
                        }
                        File tmp = new File(thumbDir(), key + ".tmp");
                        FileOutputStream fo = new FileOutputStream(tmp);
                        try {
                            if (png) b.compress(Bitmap.CompressFormat.PNG, 100, fo);
                            else b.compress(Bitmap.CompressFormat.JPEG, fit ? 86 : 76, fo);
                        } finally {
                            fo.close();
                        }
                        b.recycle();
                        if (!tmp.renameTo(out)) {
                            call.reject("cannot cache thumbnail");
                            return;
                        }
                    }
                    JSObject r = new JSObject();
                    r.put("path", out.getAbsolutePath());
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        };
        (prio ? prevPool : thumbPool).execute(job);
    }

    @PluginMethod
    public void clearThumbs(final PluginCall call) {
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                long freed = 0;
                try {
                    File[] fs = thumbDir().listFiles();
                    if (fs != null) {
                        for (File f : fs) {
                            freed += f.length();
                            f.delete();
                        }
                    }
                } catch (Throwable ignored) {}
                JSObject r = new JSObject();
                r.put("freed", freed);
                call.resolve(r);
            }
        });
    }

    /* ---------- zip / extract with progress + cancel ---------- */

    private FzCore.Progress progress(final String id) {
        return new FzCore.Progress() {
            @Override
            public void onProgress(long done, long total, String name) {
                JSObject o = new JSObject();
                o.put("id", id);
                o.put("done", done);
                o.put("total", total);
                o.put("name", name == null ? "" : name);
                notifyListeners("fzprog", o);
            }

            @Override
            public boolean cancelled() {
                return cancels.containsKey(id);
            }
        };
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        String id = call.getString("id");
        if (id != null) cancels.put(id, Boolean.TRUE);
        call.resolve();
    }

    @PluginMethod
    public void zip(final PluginCall call) {
        final String id = call.getString("id", "job");
        final String dest = call.getString("dest");
        final List<String> paths = strings(call.getArray("paths"));
        if (dest == null || paths.isEmpty()) {
            call.reject("nothing to compress");
            return;
        }
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    List<File> srcs = new ArrayList<File>();
                    for (String p : paths) srcs.add(new File(p));
                    File out = FzCore.zip(srcs, new File(dest), progress(id));
                    JSObject r = new JSObject();
                    r.put("path", out.getAbsolutePath());
                    r.put("size", out.length());
                    call.resolve(r);
                } catch (FzCore.Cancelled c) {
                    call.reject("cancelled");
                } catch (Throwable e) {
                    call.reject(msg(e));
                } finally {
                    cancels.remove(id);
                }
            }
        });
    }

    @PluginMethod
    public void unzip(final PluginCall call) {
        final String id = call.getString("id", "job");
        final String path = call.getString("path");
        final String dest = call.getString("dest");
        final boolean wrap = Boolean.TRUE.equals(call.getBoolean("wrap", Boolean.TRUE));
        if (path == null || dest == null) {
            call.reject("path and dest are required");
            return;
        }
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    FzCore.Result res = FzCore.extract(new File(path), new File(dest), wrap, progress(id));
                    JSObject r = new JSObject();
                    r.put("dest", res.dest.getAbsolutePath());
                    r.put("files", res.files);
                    r.put("bytes", res.bytes);
                    call.resolve(r);
                } catch (FzCore.Cancelled c) {
                    call.reject("cancelled");
                } catch (Throwable e) {
                    call.reject(msg(e));
                } finally {
                    cancels.remove(id);
                }
            }
        });
    }

    @PluginMethod
    public void zipList(final PluginCall call) {
        final String path = call.getString("path");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    FzCore.Listing l = FzCore.list(new File(path), 400);
                    JSArray arr = new JSArray();
                    for (FzCore.Entry e : l.entries) {
                        JSObject o = new JSObject();
                        o.put("n", e.name);
                        o.put("s", e.size);
                        o.put("d", e.dir);
                        arr.put(o);
                    }
                    JSObject r = new JSObject();
                    r.put("entries", arr);
                    r.put("total", l.total);
                    r.put("bytes", l.bytes);
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        });
    }

    /* ---------- open with / share ---------- */

    private Uri uriFor(String path) throws Exception {
        File f = new File(path);
        Class<?> cls = Class.forName("androidx.core.content.FileProvider");
        Method m = cls.getMethod("getUriForFile", Context.class, String.class, File.class);
        return (Uri) m.invoke(null, getContext(),
                getContext().getPackageName() + ".fileprovider", f);
    }

    @PluginMethod
    public void open(PluginCall call) {
        String path = call.getString("path");
        String mime = call.getString("mime", "*/*");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uriFor(path), mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("cannot open: " + e.getMessage());
        }
    }

    @PluginMethod
    public void share(PluginCall call) {
        String path = call.getString("path");
        String mime = call.getString("mime", "*/*");
        String title = call.getString("title", "Share");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_STREAM, uriFor(path));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(i, title);
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("cannot share: " + e.getMessage());
        }
    }

    @PluginMethod
    public void shareMany(PluginCall call) {
        List<String> paths = strings(call.getArray("paths"));
        String title = call.getString("title", "Share");
        if (paths.isEmpty()) {
            call.reject("nothing to share");
            return;
        }
        try {
            ArrayList<Uri> uris = new ArrayList<Uri>();
            for (String p : paths) uris.add(uriFor(p));
            Intent i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.setType("*/*");
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(i, title);
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("cannot share: " + e.getMessage());
        }
    }
}

/* ======================================================================
 * Engine used by the plugin above. Kept in this same file on purpose, so any
 * build that copies just PermPlugin.java + MainActivity.java still compiles.
 * ====================================================================== */
final class FzCore {

    private FzCore() {}

    /* ------------------------------------------------------------------ */
    /* progress + cancel                                                    */
    /* ------------------------------------------------------------------ */

    public interface Progress {
        void onProgress(long done, long total, String name);
        boolean cancelled();
    }

    public static class Cancelled extends IOException {
        public Cancelled() { super("cancelled"); }
    }

    /** Throttles progress callbacks so the UI bridge is never flooded. */
    private static final class Ticker {
        final Progress p; final long total; long done; long last; String name = "";
        Ticker(Progress p, long total) { this.p = p; this.total = total; }
        void add(long n, String nm) throws IOException {
            done += n;
            if (nm != null) name = nm;
            if (p == null) return;
            if (p.cancelled()) throw new Cancelled();
            long now = System.currentTimeMillis();
            if (now - last >= 90) { last = now; p.onProgress(done, total, name); }
        }
        void finish() { if (p != null) p.onProgress(total > 0 ? total : done, total, name); }
    }

    /* ------------------------------------------------------------------ */
    /* helpers                                                              */
    /* ------------------------------------------------------------------ */

    static String ext(String n) {
        int i = n.lastIndexOf('.');
        return i > 0 ? n.substring(i + 1).toLowerCase(Locale.ROOT) : "";
    }

    /** Returns f, or "name (1).ext", "name (2).ext"… if it already exists. */
    public static File unique(File f) {
        if (!f.exists()) return f;
        File dir = f.getParentFile();
        String n = f.getName();
        String low = n.toLowerCase(Locale.ROOT);
        String b = n, e = "";
        if (low.endsWith(".tar.gz")) { b = n.substring(0, n.length() - 7); e = n.substring(n.length() - 7); }
        else {
            int i = n.lastIndexOf('.');
            if (i > 0) { b = n.substring(0, i); e = n.substring(i); }
        }
        for (int c = 1; c < 10000; c++) {
            File g = new File(dir, b + " (" + c + ")" + e);
            if (!g.exists()) return g;
        }
        return f;
    }

    /** True when f is a symlink that points outside its parent (loop guard). */
    private static boolean escapes(File f, String parentCanon) {
        try {
            String c = f.getCanonicalPath();
            return !c.startsWith(parentCanon + File.separator);
        } catch (IOException e) {
            return true;
        }
    }

    private static boolean isZipName(String low) {
        return low.endsWith(".zip") || low.endsWith(".jar") || low.endsWith(".cbz") || low.endsWith(".xapk")
                || low.endsWith(".apks") || low.endsWith(".apk") || low.endsWith(".aab");
    }

    private static boolean isTarGz(String low) { return low.endsWith(".tar.gz") || low.endsWith(".tgz"); }

    private static boolean isTar(String low) { return low.endsWith(".tar"); }

    private static boolean isGz(String low) { return low.endsWith(".gz"); }

    public static boolean canExtract(String name) {
        String low = name.toLowerCase(Locale.ROOT);
        return isZipName(low) || isTarGz(low) || isTar(low) || isGz(low);
    }

    /** Folder name used when extracting "here": archive name without its extension(s). */
    public static String stem(String name) {
        String low = name.toLowerCase(Locale.ROOT);
        if (low.endsWith(".tar.gz")) return name.substring(0, name.length() - 7);
        int i = name.lastIndexOf('.');
        return i > 0 ? name.substring(0, i) : name + "_extracted";
    }

    private static String jstr(String s) {
        StringBuilder b = new StringBuilder(s.length() + 8);
        b.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\') { b.append('\\').append(c); }
            else if (c < 0x20) { b.append(String.format("\\u%04x", (int) c)); }
            else b.append(c);
        }
        return b.append('"').toString();
    }

    /* ------------------------------------------------------------------ */
    /* storage index                                                        */
    /* ------------------------------------------------------------------ */

    /**
     * Walks the whole tree once and writes a compact JSON array:
     * [[path,size,mtime,isDir],…]. Hidden (dot) entries and Android/ are skipped.
     * Returns the number of entries written.
     */
    public static int index(File root, File out, int maxDepth) throws IOException {
        File tmp = new File(out.getPath() + ".tmp");
        int[] n = {0};
        try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tmp), "UTF-8"), 1 << 16)) {
            w.write("[");
            walk(root, 0, maxDepth, w, n);
            w.write("]");
        }
        if (out.exists()) out.delete();
        if (!tmp.renameTo(out)) throw new IOException("cannot write index");
        return n[0];
    }

    private static void walk(File dir, int depth, int maxDepth, BufferedWriter w, int[] n) throws IOException {
        File[] list = dir.listFiles();
        if (list == null) return;
        String canon;
        try { canon = dir.getCanonicalPath(); } catch (IOException e) { return; }
        for (File f : list) {
            String name = f.getName();
            if (name.length() == 0 || name.charAt(0) == '.') continue;
            if (f.isDirectory()) {
                if (depth == 0 && name.equals("Android")) continue;
                if (name.equals("lost+found")) continue;
                emit(w, n, f.getAbsolutePath(), 0, f.lastModified(), 1);
                if (depth < maxDepth && !escapes(f, canon)) walk(f, depth + 1, maxDepth, w, n);
            } else {
                emit(w, n, f.getAbsolutePath(), f.length(), f.lastModified(), 0);
            }
        }
    }

    private static void emit(BufferedWriter w, int[] n, String path, long size, long mtime, int dir) throws IOException {
        if (n[0] > 0) w.write(',');
        w.write('[');
        w.write(jstr(path));
        w.write(',');
        w.write(Long.toString(size));
        w.write(',');
        w.write(Long.toString(mtime));
        w.write(',');
        w.write(dir == 1 ? '1' : '0');
        w.write(']');
        n[0]++;
    }

    /** Total size and file count of a folder (or a single file). */
    public static long[] dirSize(File f) {
        long[] r = {0, 0};
        sizeInto(f, r, 0);
        return r;
    }

    private static void sizeInto(File f, long[] r, int depth) {
        if (depth > 40) return;
        if (f.isDirectory()) {
            File[] c = f.listFiles();
            if (c == null) return;
            String canon;
            try { canon = f.getCanonicalPath(); } catch (IOException e) { return; }
            for (File x : c) {
                if (x.isDirectory() && escapes(x, canon)) continue;
                sizeInto(x, r, depth + 1);
            }
        } else {
            r[0] += f.length();
            r[1]++;
        }
    }

    /* ------------------------------------------------------------------ */
    /* duplicate fingerprint                                                */
    /* ------------------------------------------------------------------ */

    /** SHA-1 over size + head/middle/tail samples (whole file when small). */
    public static String fingerprint(File f) throws Exception {
        long len = f.length();
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        md.update(Long.toString(len).getBytes("UTF-8"));
        final int S = 1 << 20;
        byte[] buf = new byte[1 << 16];
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            long[] offs;
            if (len <= 3L * S) offs = new long[]{0};
            else offs = new long[]{0, len / 2 - S / 2, len - S};
            for (long off : offs) {
                r.seek(off);
                long left = len <= 3L * S ? len : S;
                while (left > 0) {
                    int k = r.read(buf, 0, (int) Math.min(buf.length, left));
                    if (k <= 0) break;
                    md.update(buf, 0, k);
                    left -= k;
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    /* ------------------------------------------------------------------ */
    /* ZIP create                                                           */
    /* ------------------------------------------------------------------ */

    private static boolean alreadyCompressed(String e) {
        switch (e) {
            case "jpg": case "jpeg": case "png": case "webp": case "gif": case "heic": case "heif": case "avif":
            case "mp4": case "mkv": case "webm": case "mov": case "3gp": case "avi": case "m4v":
            case "mp3": case "m4a": case "aac": case "ogg": case "opus": case "flac":
            case "zip": case "rar": case "7z": case "gz": case "tgz": case "bz2": case "xz": case "apk":
            case "jar": case "docx": case "xlsx": case "pptx": case "epub": case "pdf":
                return true;
            default:
                return false;
        }
    }

    /**
     * Compresses files/folders into a ZIP. Writes to name.zip.part, then renames to a unique name.
     * Returns the final file.
     */
    public static File zip(List<File> srcs, File dest, Progress p) throws IOException {
        long total = 0;
        for (File s : srcs) total += dirSize(s)[0];
        File parent = dest.getParentFile();
        if (parent != null) parent.mkdirs();
        File tmp = new File(dest.getPath() + ".part");
        Ticker t = new Ticker(p, total);
        Set<String> used = new HashSet<>();
        boolean ok = false;
        try (ZipOutputStream z = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tmp), 1 << 16))) {
            z.setLevel(Deflater.DEFAULT_COMPRESSION);
            for (File s : srcs) {
                String en = s.getName();
                int c = 1;
                while (used.contains(en)) en = s.getName() + "_" + (c++);
                used.add(en);
                addEntry(z, s, en, t, tmp, dest);
            }
            ok = true;
        } finally {
            if (!ok) tmp.delete();
        }
        File fin = unique(dest);
        if (!tmp.renameTo(fin)) { tmp.delete(); throw new IOException("cannot save zip"); }
        t.finish();
        return fin;
    }

    private static void addEntry(ZipOutputStream z, File f, String entry, Ticker t, File tmp, File dest) throws IOException {
        if (f.equals(tmp) || f.equals(dest)) return;
        if (f.isDirectory()) {
            String en = entry.endsWith("/") ? entry : entry + "/";
            ZipEntry ze = new ZipEntry(en);
            ze.setTime(f.lastModified());
            z.putNextEntry(ze);
            z.closeEntry();
            File[] kids = f.listFiles();
            if (kids == null) return;
            Arrays.sort(kids);
            String canon;
            try { canon = f.getCanonicalPath(); } catch (IOException e) { return; }
            for (File k : kids) {
                if (k.isDirectory() && escapes(k, canon)) continue;
                addEntry(z, k, en + k.getName(), t, tmp, dest);
            }
        } else {
            z.setLevel(alreadyCompressed(ext(f.getName())) ? Deflater.NO_COMPRESSION : Deflater.DEFAULT_COMPRESSION);
            ZipEntry ze = new ZipEntry(entry);
            ze.setTime(f.lastModified());
            z.putNextEntry(ze);
            byte[] buf = new byte[1 << 16];
            try (InputStream in = new FileInputStream(f)) {
                int n;
                t.add(0, f.getName());
                while ((n = in.read(buf)) > 0) {
                    z.write(buf, 0, n);
                    t.add(n, null);
                }
            } catch (Cancelled c) {
                throw c;
            } catch (IOException e) {
                // unreadable file: skip it rather than fail the whole archive
            }
            z.closeEntry();
        }
    }

    /* ------------------------------------------------------------------ */
    /* extract                                                              */
    /* ------------------------------------------------------------------ */

    public static final class Result {
        public File dest;
        public int files;
        public long bytes;
    }

    public static Result extract(File arc, File destRoot, boolean wrap, Progress p) throws IOException {
        String low = arc.getName().toLowerCase(Locale.ROOT);
        if (!canExtract(arc.getName())) throw new IOException("Unsupported archive type");
        File dest = wrap ? unique(new File(destRoot, stem(arc.getName()))) : destRoot;
        if (!dest.exists() && !dest.mkdirs()) throw new IOException("Cannot create folder");
        Result r = new Result();
        r.dest = dest;
        boolean ok = false;
        try {
            if (isZipName(low)) extractZip(arc, dest, p, r);
            else if (isTarGz(low)) extractTarStream(arc, true, dest, p, r);
            else if (isTar(low)) extractTarStream(arc, false, dest, p, r);
            else extractGz(arc, dest, p, r);
            ok = true;
        } finally {
            if (!ok && wrap && r.files == 0) deleteQuiet(dest);
        }
        return r;
    }

    private static void deleteQuiet(File f) {
        File[] k = f.listFiles();
        if (k != null) for (File x : k) deleteQuiet(x);
        f.delete();
    }

    private static ZipFile openZip(File f) throws IOException {
        try {
            return new ZipFile(f, Charset.forName("UTF-8"));
        } catch (IllegalArgumentException | java.util.zip.ZipException e) {
            return new ZipFile(f, Charset.forName("ISO-8859-1"));
        }
    }

    /** Resolves an archive entry name inside dest; returns null for unsafe (zip-slip) names. */
    private static File safe(File dest, String name) throws IOException {
        name = name.replace('\\', '/');
        while (name.startsWith("/")) name = name.substring(1);
        if (name.length() == 0) return null;
        File out = new File(dest, name);
        String base = dest.getCanonicalPath() + File.separator;
        String target = out.getCanonicalPath();
        if (!(target + File.separator).startsWith(base)) return null;
        return out;
    }

    private static void extractZip(File arc, File dest, Progress p, Result r) throws IOException {
        try (ZipFile zf = openZip(arc)) {
            long total = 0;
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (!e.isDirectory() && e.getSize() > 0) total += e.getSize();
            }
            Ticker t = new Ticker(p, total);
            en = zf.entries();
            byte[] buf = new byte[1 << 16];
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                File out = safe(dest, e.getName());
                if (out == null) continue;
                if (e.isDirectory()) { out.mkdirs(); continue; }
                File par = out.getParentFile();
                if (par != null && !par.exists()) par.mkdirs();
                if (par != null && !par.isDirectory()) continue;
                if (out.exists()) out = unique(out);
                t.add(0, out.getName());
                try (InputStream in = zf.getInputStream(e); OutputStream os = new BufferedOutputStream(new FileOutputStream(out), 1 << 16)) {
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        os.write(buf, 0, n);
                        r.bytes += n;
                        t.add(n, null);
                    }
                } catch (Cancelled c) {
                    out.delete();
                    throw c;
                } catch (IOException ex) {
                    out.delete();
                    throw new IOException("Could not read \"" + e.getName() + "\" (password-protected or damaged archive?)");
                }
                if (e.getTime() > 0) out.setLastModified(e.getTime());
                r.files++;
            }
            t.finish();
        }
    }

    private static void extractGz(File arc, File dest, Progress p, Result r) throws IOException {
        String nm = arc.getName();
        String out = nm.substring(0, nm.length() - 3);
        if (out.length() == 0) out = "extracted";
        File of = unique(new File(dest, out));
        Ticker t = new Ticker(p, arc.length());
        byte[] buf = new byte[1 << 16];
        try (CountingIn raw = new CountingIn(new FileInputStream(arc));
             GZIPInputStream gz = new GZIPInputStream(raw, 1 << 16);
             OutputStream os = new BufferedOutputStream(new FileOutputStream(of), 1 << 16)) {
            int n;
            long seen = 0;
            t.add(0, of.getName());
            while ((n = gz.read(buf)) > 0) {
                os.write(buf, 0, n);
                r.bytes += n;
                long c = raw.count;
                t.add(c - seen, null);
                seen = c;
            }
        } catch (Cancelled c) {
            of.delete();
            throw c;
        }
        r.files = 1;
        t.finish();
    }

    private static final class CountingIn extends FilterInputStream {
        long count;
        CountingIn(InputStream in) { super(in); }
        @Override public int read() throws IOException { int b = super.read(); if (b >= 0) count++; return b; }
        @Override public int read(byte[] b, int o, int l) throws IOException { int n = super.read(b, o, l); if (n > 0) count += n; return n; }
    }

    /* ---------- tar ---------- */

    private static boolean readFully(InputStream in, byte[] b, int len) throws IOException {
        int o = 0;
        while (o < len) {
            int n = in.read(b, o, len - o);
            if (n < 0) return o > 0 && false;
            o += n;
        }
        return true;
    }

    private static void skipFully(InputStream in, long n) throws IOException {
        byte[] sink = new byte[1 << 13];
        while (n > 0) {
            long s = in.skip(n);
            if (s <= 0) {
                int k = in.read(sink, 0, (int) Math.min(sink.length, n));
                if (k < 0) return;
                s = k;
            }
            n -= s;
        }
    }

    private static String cstr(byte[] b, int off, int len) {
        int e = off;
        while (e < off + len && b[e] != 0) e++;
        try { return new String(b, off, e - off, "UTF-8"); } catch (Exception x) { return ""; }
    }

    private static long octal(byte[] b, int off, int len) {
        // GNU base-256 for huge sizes
        if ((b[off] & 0x80) != 0) {
            long v = 0;
            for (int i = 1; i < len; i++) v = (v << 8) | (b[off + i] & 0xff);
            return v;
        }
        long v = 0;
        for (int i = off; i < off + len; i++) {
            int c = b[i];
            if (c == 0 || c == ' ') { if (v == 0 && c == ' ') continue; if (c == 0) break; else break; }
            if (c < '0' || c > '7') break;
            v = (v << 3) + (c - '0');
        }
        return v;
    }

    private static boolean zeroBlock(byte[] b) {
        for (int i = 0; i < 512; i++) if (b[i] != 0) return false;
        return true;
    }

    /** One parsed tar header. */
    private static final class TarHead { String name; long size; char type; }

    /** Reads the next real header (resolving GNU long names and PAX paths). Returns null at the end. */
    private static TarHead nextHead(InputStream in, byte[] h) throws IOException {
        String longName = null;
        while (true) {
            if (!readFully(in, h, 512)) return null;
            if (zeroBlock(h)) return null;
            String name = cstr(h, 0, 100);
            long size = octal(h, 124, 12);
            char type = (char) (h[156] & 0xff);
            String magic = cstr(h, 257, 5);
            if ("ustar".equals(magic)) {
                String prefix = cstr(h, 345, 155);
                if (prefix.length() > 0) name = prefix + "/" + name;
            }
            if (type == 'L') {
                byte[] nb = new byte[(int) size];
                readFully(in, nb, nb.length);
                skipFully(in, (512 - size % 512) % 512);
                longName = cstr(nb, 0, nb.length);
                continue;
            }
            if (type == 'x' || type == 'g') {
                byte[] pb = new byte[(int) size];
                readFully(in, pb, pb.length);
                skipFully(in, (512 - size % 512) % 512);
                if (type == 'x') {
                    String s;
                    try { s = new String(pb, "UTF-8"); } catch (Exception e) { s = ""; }
                    int i = s.indexOf(" path=");
                    if (i >= 0) {
                        int e = s.indexOf('\n', i);
                        if (e > i) longName = s.substring(i + 6, e);
                    }
                }
                continue;
            }
            TarHead th = new TarHead();
            th.name = longName != null ? longName : name;
            th.size = size;
            th.type = type;
            return th;
        }
    }

    private static InputStream openTar(File arc, boolean gz, CountingIn[] holder) throws IOException {
        CountingIn raw = new CountingIn(new FileInputStream(arc));
        holder[0] = raw;
        return gz ? new GZIPInputStream(raw, 1 << 16) : raw;
    }

    private static void extractTarStream(File arc, boolean gz, File dest, Progress p, Result r) throws IOException {
        CountingIn[] holder = new CountingIn[1];
        Ticker t = new Ticker(p, arc.length());
        byte[] h = new byte[512];
        byte[] buf = new byte[1 << 16];
        try (InputStream in = openTar(arc, gz, holder)) {
            long seen = 0;
            TarHead th;
            while ((th = nextHead(in, h)) != null) {
                boolean file = th.type == '0' || th.type == 0 || th.type == '7';
                boolean dir = th.type == '5';
                File out = (file || dir) ? safe(dest, th.name) : null;
                long remain = th.size;
                if (out != null && dir) {
                    out.mkdirs();
                } else if (out != null && file) {
                    File par = out.getParentFile();
                    if (par != null && !par.exists()) par.mkdirs();
                    if (out.exists()) out = unique(out);
                    t.add(0, out.getName());
                    try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out), 1 << 16)) {
                        while (remain > 0) {
                            int k = in.read(buf, 0, (int) Math.min(buf.length, remain));
                            if (k < 0) throw new IOException("Archive is truncated");
                            os.write(buf, 0, k);
                            remain -= k;
                            r.bytes += k;
                            long c = holder[0].count;
                            t.add(c - seen, null);
                            seen = c;
                        }
                    } catch (Cancelled c) {
                        out.delete();
                        throw c;
                    }
                    r.files++;
                }
                if (remain > 0) skipFully(in, remain);
                skipFully(in, (512 - th.size % 512) % 512);
            }
        }
        t.finish();
    }

    /* ------------------------------------------------------------------ */
    /* archive listing                                                      */
    /* ------------------------------------------------------------------ */

    public static final class Entry {
        public final String name; public final long size; public final boolean dir;
        Entry(String n, long s, boolean d) { name = n; size = s; dir = d; }
    }

    public static final class Listing {
        public final List<Entry> entries = new ArrayList<>();
        public int total;
        public long bytes;
    }

    public static Listing list(File arc, int max) throws IOException {
        String low = arc.getName().toLowerCase(Locale.ROOT);
        Listing L = new Listing();
        if (isZipName(low)) {
            try (ZipFile zf = openZip(arc)) {
                Enumeration<? extends ZipEntry> en = zf.entries();
                while (en.hasMoreElements()) {
                    ZipEntry e = en.nextElement();
                    L.total++;
                    if (!e.isDirectory() && e.getSize() > 0) L.bytes += e.getSize();
                    if (L.entries.size() < max) L.entries.add(new Entry(e.getName(), Math.max(0, e.getSize()), e.isDirectory()));
                }
            }
        } else if (isTarGz(low) || isTar(low)) {
            CountingIn[] holder = new CountingIn[1];
            byte[] h = new byte[512];
            try (InputStream in = openTar(arc, isTarGz(low), holder)) {
                TarHead th;
                while ((th = nextHead(in, h)) != null) {
                    boolean dir = th.type == '5';
                    boolean file = th.type == '0' || th.type == 0 || th.type == '7';
                    if (file || dir) {
                        L.total++;
                        if (file) L.bytes += th.size;
                        if (L.entries.size() < max) L.entries.add(new Entry(th.name, th.size, dir));
                    }
                    skipFully(in, th.size + (512 - th.size % 512) % 512);
                }
            }
        } else if (isGz(low)) {
            String nm = arc.getName();
            L.entries.add(new Entry(nm.substring(0, nm.length() - 3), 0, false));
            L.total = 1;
        } else {
            throw new IOException("Unsupported archive type");
        }
        return L;
    }
}
