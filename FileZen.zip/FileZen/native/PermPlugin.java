package com.filezen.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.zip.Deflater;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * FileZen native engine (one Capacitor plugin).
 *
 * Imports nothing outside the Android framework and Capacitor core. FileProvider is reached
 * through reflection so the app still compiles without androidx.core on the classpath.
 * Every heavy call runs on its own thread pool so the UI bridge never blocks, and every
 * failure becomes a rejected promise instead of a crash.
 */
@CapacitorPlugin(name = "Perm")
public class PermPlugin extends Plugin {

    private static ExecutorService pool(final String name, int n) {
        return Executors.newFixedThreadPool(n, new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, name);
                t.setDaemon(true);
                t.setPriority(Thread.NORM_PRIORITY - 1);
                return t;
            }
        });
    }

    private final ExecutorService listPool = pool("fz-list", 2);
    private final ExecutorService idxPool = pool("fz-index", 1);
    private final ExecutorService thumbPool = pool("fz-thumb", 3);
    private final ExecutorService prevPool = pool("fz-preview", 1);
    private final ExecutorService ioPool = pool("fz-io", 2);
    private final ConcurrentHashMap<String, Boolean> cancels = new ConcurrentHashMap<String, Boolean>();

    private static String msg(Throwable e) {
        String m = e.getMessage();
        return m == null || m.length() == 0 ? e.getClass().getSimpleName() : m;
    }

    private static List<String> strings(JSArray a) {
        List<String> out = new ArrayList<String>();
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            try {
                String s = a.getString(i);
                if (s != null) out.add(s);
            } catch (Exception ignored) {}
        }
        return out;
    }

    /* ---------- storage permission + totals ---------- */

    @PluginMethod
    public void check(PluginCall call) {
        JSObject o = new JSObject();
        boolean granted = Build.VERSION.SDK_INT >= 30 ? Environment.isExternalStorageManager() : true;
        long total = 0L;
        long free = 0L;
        try {
            StatFs s = new StatFs(Environment.getExternalStorageDirectory().getPath());
            total = s.getTotalBytes();
            free = s.getAvailableBytes();
        } catch (Exception ignored) {}
        o.put("granted", granted);
        o.put("total", total);
        o.put("free", free);
        call.resolve(o);
    }

    @PluginMethod
    public void request(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            }
        } catch (Exception ignored) {}
        call.resolve();
    }

    /* ---------- status / navigation bar colours ---------- */

    @PluginMethod
    public void setBars(PluginCall call) {
        final String status = call.getString("status", "#0B0B0D");
        final String nav = call.getString("nav", "#0B0B0D");
        final boolean lightIcons = Boolean.TRUE.equals(call.getBoolean("light", Boolean.FALSE));
        if (getActivity() == null) {
            call.resolve();
            return;
        }
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Window w = getActivity().getWindow();
                    w.setStatusBarColor(Color.parseColor(status));
                    w.setNavigationBarColor(Color.parseColor(nav));
                    View dv = w.getDecorView();
                    int flags = dv.getSystemUiVisibility();
                    if (lightIcons) {
                        flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    } else {
                        flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    }
                    dv.setSystemUiVisibility(flags);
                } catch (Exception ignored) {}
            }
        });
        call.resolve();
    }

    /* ---------- fast directory listing (one call, no per-file bridge cost) ---------- */

    @PluginMethod
    public void list(final PluginCall call) {
        final String path = call.getString("path");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        listPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    File[] fs = new File(path).listFiles();
                    if (fs == null) {
                        call.reject("cannot read folder");
                        return;
                    }
                    JSArray arr = new JSArray();
                    for (File f : fs) {
                        JSObject o = new JSObject();
                        boolean d = f.isDirectory();
                        o.put("name", f.getName());
                        o.put("type", d ? "directory" : "file");
                        o.put("size", d ? 0L : f.length());
                        o.put("mtime", f.lastModified());
                        arr.put(o);
                    }
                    JSObject r = new JSObject();
                    r.put("files", arr);
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        });
    }

    /* ---------- whole-storage index (written to a file, read back by the WebView) ---------- */

    @PluginMethod
    public void index(final PluginCall call) {
        idxPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    File out = new File(getContext().getCacheDir(), "fzidx.json");
                    int n = FzCore.index(Environment.getExternalStorageDirectory(), out, 20);
                    JSObject r = new JSObject();
                    r.put("path", out.getAbsolutePath());
                    r.put("count", n);
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        });
    }

    @PluginMethod
    public void dirSize(final PluginCall call) {
        final String path = call.getString("path");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    long[] s = FzCore.dirSize(new File(path));
                    JSObject r = new JSObject();
                    r.put("size", s[0]);
                    r.put("count", s[1]);
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        });
    }

    @PluginMethod
    public void hash(final PluginCall call) {
        final List<String> paths = strings(call.getArray("paths"));
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                JSArray out = new JSArray();
                for (String p : paths) {
                    String h = "";
                    try { h = FzCore.fingerprint(new File(p)); } catch (Throwable ignored) {}
                    out.put(h);
                }
                JSObject r = new JSObject();
                r.put("hashes", out);
                call.resolve(r);
            }
        });
    }

    /* ---------- media scanner (keeps Gallery in sync after file changes) ---------- */

    @PluginMethod
    public void scan(PluginCall call) {
        final List<String> l = strings(call.getArray("paths"));
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    List<String> out = new ArrayList<String>();
                    for (String p : l) expand(new File(p), out, 0);
                    if (!out.isEmpty()) {
                        MediaScannerConnection.scanFile(getContext(), out.toArray(new String[0]), null, null);
                    }
                } catch (Throwable ignored) {}
            }
        });
        call.resolve();
    }

    /** Folders expand to their files; missing paths are passed through so stale Gallery entries get removed. */
    private static void expand(File f, List<String> out, int depth) {
        if (out.size() > 3000 || depth > 12) return;
        if (f.isDirectory()) {
            File[] k = f.listFiles();
            if (k != null) for (File x : k) expand(x, out, depth + 1);
        } else {
            out.add(f.getAbsolutePath());
        }
    }

    /* ---------- thumbnails ---------- */

    private File thumbDir() {
        File d = new File(getContext().getCacheDir(), "fzt");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static String sha1(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] b = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 10; i++) sb.append(String.format("%02x", b[i]));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(s.hashCode());
        }
    }

    private static String ext(String n) {
        int i = n.lastIndexOf('.');
        return i > 0 ? n.substring(i + 1).toLowerCase(Locale.ROOT) : "";
    }

    private static boolean in(String e, String... a) {
        for (String x : a) if (x.equals(e)) return true;
        return false;
    }

    /** Decodes with a power-of-two sample so the short (crop) or long (fit) side stays >= target. */
    private static Bitmap decode(String path, byte[] bytes, int target, boolean fit) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        if (bytes != null) BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o);
        else BitmapFactory.decodeFile(path, o);
        if (o.outWidth <= 0 || o.outHeight <= 0) return null;
        int side = fit ? Math.max(o.outWidth, o.outHeight) : Math.min(o.outWidth, o.outHeight);
        int s = 1;
        while (side / (s * 2) >= target) s *= 2;
        BitmapFactory.Options d = new BitmapFactory.Options();
        d.inSampleSize = s;
        d.inPreferredConfig = Bitmap.Config.ARGB_8888;
        if (bytes != null) return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, d);
        return BitmapFactory.decodeFile(path, d);
    }

    private static Bitmap rotate(Bitmap b, String path) {
        try {
            String e = ext(path);
            if (!in(e, "jpg", "jpeg", "heic", "heif")) return b;
            ExifInterface ex = new ExifInterface(path);
            int o = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            int deg = 0;
            if (o == ExifInterface.ORIENTATION_ROTATE_90) deg = 90;
            else if (o == ExifInterface.ORIENTATION_ROTATE_180) deg = 180;
            else if (o == ExifInterface.ORIENTATION_ROTATE_270) deg = 270;
            if (deg == 0) return b;
            Matrix m = new Matrix();
            m.postRotate(deg);
            Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            if (r != b) b.recycle();
            return r;
        } catch (Throwable t) {
            return b;
        }
    }

    private static Bitmap square(Bitmap src, int px) {
        int w = src.getWidth(), h = src.getHeight();
        int s = Math.min(w, h);
        Bitmap c = Bitmap.createBitmap(src, (w - s) / 2, (h - s) / 2, s, s);
        Bitmap r = c.getWidth() == px ? c : Bitmap.createScaledBitmap(c, px, px, true);
        if (c != r && c != src) c.recycle();
        if (r != src) src.recycle();
        return r;
    }

    private static Bitmap fitTo(Bitmap src, int px) {
        int w = src.getWidth(), h = src.getHeight();
        int m = Math.max(w, h);
        if (m <= px) return src;
        float k = (float) px / m;
        Bitmap r = Bitmap.createScaledBitmap(src, Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k)), true);
        if (r != src) src.recycle();
        return r;
    }

    private Bitmap apkIcon(String path, int px) {
        try {
            PackageManager pm = getContext().getPackageManager();
            PackageInfo pi = pm.getPackageArchiveInfo(path, 0);
            if (pi == null || pi.applicationInfo == null) return null;
            ApplicationInfo ai = pi.applicationInfo;
            ai.sourceDir = path;
            ai.publicSourceDir = path;
            Drawable d = ai.loadIcon(pm);
            if (d == null) return null;
            Bitmap b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            d.setBounds(0, 0, px, px);
            d.draw(c);
            return b;
        } catch (Throwable t) {
            return null;
        }
    }

    private Bitmap makeThumb(String path, int px, boolean fit) {
        String e = ext(path);
        Bitmap b = null;
        if (in(e, "jpg", "jpeg", "png", "webp", "bmp", "gif", "heic", "heif", "avif")) {
            b = decode(path, null, px, fit);
            if (b != null) b = rotate(b, path);
        } else if (in(e, "mp4", "mkv", "webm", "3gp", "avi", "mov", "m4v", "flv", "ts")) {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(path);
                b = r.getFrameAtTime(1000000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                if (b == null) b = r.getFrameAtTime();
            } catch (Throwable t) {
                b = null;
            } finally {
                try { r.release(); } catch (Throwable ignored) {}
            }
        } else if (in(e, "apk", "xapk", "apks")) {
            b = apkIcon(path, px);
            return b;
        } else if (in(e, "mp3", "m4a", "flac", "ogg", "aac", "opus", "wav", "amr", "wma")) {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(path);
                byte[] art = r.getEmbeddedPicture();
                if (art != null) b = decode(null, art, px, fit);
            } catch (Throwable t) {
                b = null;
            } finally {
                try { r.release(); } catch (Throwable ignored) {}
            }
        }
        if (b == null) return null;
        return fit ? fitTo(b, px) : square(b, px);
    }

    @PluginMethod
    public void thumb(final PluginCall call) {
        final String path = call.getString("path");
        Integer sz = call.getInt("size", 200);
        final int px = Math.max(48, Math.min(2048, sz == null ? 200 : sz));
        final boolean fit = Boolean.TRUE.equals(call.getBoolean("fit", Boolean.FALSE));
        final boolean prio = Boolean.TRUE.equals(call.getBoolean("prio", Boolean.FALSE));
        if (path == null) {
            call.reject("path is required");
            return;
        }
        Runnable job = new Runnable() {
            @Override
            public void run() {
                try {
                    File src = new File(path);
                    if (!src.exists()) {
                        call.reject("missing");
                        return;
                    }
                    boolean png = in(ext(path), "apk", "xapk", "apks");
                    String key = sha1(path + "|" + src.lastModified() + "|" + src.length() + "|" + px + (fit ? "f" : "c"));
                    File out = new File(thumbDir(), key + (png ? ".png" : ".jpg"));
                    if (!out.exists() || out.length() == 0) {
                        Bitmap b = makeThumb(path, px, fit);
                        if (b == null) {
                            call.reject("no thumbnail");
                            return;
                        }
                        File tmp = new File(thumbDir(), key + ".tmp");
                        FileOutputStream fo = new FileOutputStream(tmp);
                        try {
                            if (png) b.compress(Bitmap.CompressFormat.PNG, 100, fo);
                            else b.compress(Bitmap.CompressFormat.JPEG, fit ? 86 : 76, fo);
                        } finally {
                            fo.close();
                        }
                        b.recycle();
                        if (!tmp.renameTo(out)) {
                            call.reject("cannot cache thumbnail");
                            return;
                        }
                    }
                    JSObject r = new JSObject();
                    r.put("path", out.getAbsolutePath());
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        };
        (prio ? prevPool : thumbPool).execute(job);
    }

    @PluginMethod
    public void clearThumbs(final PluginCall call) {
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                long freed = 0;
                try {
                    File[] fs = thumbDir().listFiles();
                    if (fs != null) {
                        for (File f : fs) {
                            freed += f.length();
                            f.delete();
                        }
                    }
                } catch (Throwable ignored) {}
                JSObject r = new JSObject();
                r.put("freed", freed);
                call.resolve(r);
            }
        });
    }

    /* ---------- zip / extract with progress + cancel ---------- */

    private FzCore.Progress progress(final String id) {
        return new FzCore.Progress() {
            @Override
            public void onProgress(long done, long total, String name) {
                JSObject o = new JSObject();
                o.put("id", id);
                o.put("done", done);
                o.put("total", total);
                o.put("name", name == null ? "" : name);
                notifyListeners("fzprog", o);
            }

            @Override
            public boolean cancelled() {
                return cancels.containsKey(id);
            }
        };
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        String id = call.getString("id");
        if (id != null) cancels.put(id, Boolean.TRUE);
        call.resolve();
    }

    @PluginMethod
    public void zip(final PluginCall call) {
        final String id = call.getString("id", "job");
        final String dest = call.getString("dest");
        final List<String> paths = strings(call.getArray("paths"));
        if (dest == null || paths.isEmpty()) {
            call.reject("nothing to compress");
            return;
        }
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    List<File> srcs = new ArrayList<File>();
                    for (String p : paths) srcs.add(new File(p));
                    File out = FzCore.zip(srcs, new File(dest), progress(id));
                    JSObject r = new JSObject();
                    r.put("path", out.getAbsolutePath());
                    r.put("size", out.length());
                    call.resolve(r);
                } catch (FzCore.Cancelled c) {
                    call.reject("cancelled");
                } catch (Throwable e) {
                    call.reject(msg(e));
                } finally {
                    cancels.remove(id);
                }
            }
        });
    }

    @PluginMethod
    public void unzip(final PluginCall call) {
        final String id = call.getString("id", "job");
        final String path = call.getString("path");
        final String dest = call.getString("dest");
        final boolean wrap = Boolean.TRUE.equals(call.getBoolean("wrap", Boolean.TRUE));
        if (path == null || dest == null) {
            call.reject("path and dest are required");
            return;
        }
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    FzCore.Result res = FzCore.extract(new File(path), new File(dest), wrap, progress(id));
                    JSObject r = new JSObject();
                    r.put("dest", res.dest.getAbsolutePath());
                    r.put("files", res.files);
                    r.put("bytes", res.bytes);
                    call.resolve(r);
                } catch (FzCore.Cancelled c) {
                    call.reject("cancelled");
                } catch (Throwable e) {
                    call.reject(msg(e));
                } finally {
                    cancels.remove(id);
                }
            }
        });
    }

    @PluginMethod
    public void zipList(final PluginCall call) {
        final String path = call.getString("path");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    FzCore.Listing l = FzCore.list(new File(path), 400);
                    JSArray arr = new JSArray();
                    for (FzCore.Entry e : l.entries) {
                        JSObject o = new JSObject();
                        o.put("n", e.name);
                        o.put("s", e.size);
                        o.put("d", e.dir);
                        arr.put(o);
                    }
                    JSObject r = new JSObject();
                    r.put("entries", arr);
                    r.put("total", l.total);
                    r.put("bytes", l.bytes);
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        });
    }

    /* ---------- open with / share ---------- */

    private Uri uriFor(String path) throws Exception {
        File f = new File(path);
        Class<?> cls = Class.forName("androidx.core.content.FileProvider");
        Method m = cls.getMethod("getUriForFile", Context.class, String.class, File.class);
        return (Uri) m.invoke(null, getContext(),
                getContext().getPackageName() + ".fileprovider", f);
    }

    @PluginMethod
    public void open(PluginCall call) {
        String path = call.getString("path");
        String mime = call.getString("mime", "*/*");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uriFor(path), mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("cannot open: " + e.getMessage());
        }
    }

    @PluginMethod
    public void share(PluginCall call) {
        String path = call.getString("path");
        String mime = call.getString("mime", "*/*");
        String title = call.getString("title", "Share");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_STREAM, uriFor(path));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(i, title);
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("cannot share: " + e.getMessage());
        }
    }

    @PluginMethod
    public void shareMany(PluginCall call) {
        List<String> paths = strings(call.getArray("paths"));
        String title = call.getString("title", "Share");
        if (paths.isEmpty()) {
            call.reject("nothing to share");
            return;
        }
        try {
            ArrayList<Uri> uris = new ArrayList<Uri>();
            for (String p : paths) uris.add(uriFor(p));
            Intent i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.setType("*/*");
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(i, title);
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("cannot share: " + e.getMessage());
        }
    }

    /* ====================================================================== */
    /* Phone-to-phone transfer (AirLink)                                       */
    /* ====================================================================== */

    private final ExecutorService netPool = pool("fz-net", 6);
    private volatile FzNet.Receiver receiver;
    private final ConcurrentHashMap<String, FzNet.Token> sends = new ConcurrentHashMap<String, FzNet.Token>();

    private String deviceName() {
        String n = null;
        try { n = Settings.Global.getString(getContext().getContentResolver(), "device_name"); } catch (Throwable ignored) {}
        if (n == null || n.trim().length() == 0) n = Build.MODEL;
        return n == null ? "Android phone" : n;
    }

    private final FzNet.Listener xl = new FzNet.Listener() {
        @Override
        void onOffer(String id, String sender, String ip, List<FzNet.Offered> files, long total, String code) {
            JSObject o = new JSObject();
            JSArray arr = new JSArray();
            int n = 0;
            for (FzNet.Offered f : files) {
                if (n++ >= 60) break;
                JSObject x = new JSObject();
                x.put("n", f.rel);
                x.put("s", f.size);
                arr.put(x);
            }
            o.put("id", id);
            o.put("sender", sender);
            o.put("ip", ip);
            o.put("count", files.size());
            o.put("total", total);
            o.put("code", code);
            o.put("files", arr);
            notifyListeners("xferOffer", o);
        }

        @Override
        void onCode(String id, String code) {
            JSObject o = new JSObject();
            o.put("id", id);
            o.put("code", code);
            notifyListeners("xferCode", o);
        }

        @Override
        void onProgress(String id, String role, long done, long total, String name, double bps, int fileIdx, int fileCount) {
            JSObject o = new JSObject();
            o.put("id", id);
            o.put("role", role);
            o.put("done", done);
            o.put("total", total);
            o.put("name", name == null ? "" : name);
            o.put("bps", bps);
            o.put("idx", fileIdx);
            o.put("count", fileCount);
            notifyListeners("xferProg", o);
        }

        @Override
        void onDone(String id, String role, boolean ok, int count, long bytes, String dest, String error) {
            JSObject o = new JSObject();
            o.put("id", id);
            o.put("role", role);
            o.put("ok", ok);
            o.put("count", count);
            o.put("bytes", bytes);
            o.put("dest", dest == null ? "" : dest);
            o.put("error", error == null ? "" : error);
            notifyListeners("xferDone", o);
            if (ok && dest != null) {
                try { MediaScannerConnection.scanFile(getContext(), new String[]{dest}, null, null); } catch (Throwable ignored) {}
            }
        }
    };

    @PluginMethod
    public void xferInfo(PluginCall call) {
        JSObject r = new JSObject();
        JSArray ips = new JSArray();
        for (String[] a : FzNet.localAddrs()) {
            JSObject x = new JSObject();
            x.put("ip", a[0]);
            x.put("iface", a[1]);
            ips.put(x);
        }
        r.put("name", deviceName());
        r.put("addrs", ips);
        r.put("port", FzNet.PORT);
        r.put("listening", receiver != null && receiver.isRunning());
        call.resolve(r);
    }

    @PluginMethod
    public void xferListen(final PluginCall call) {
        final String dest = call.getString("dest");
        final String name = call.getString("name", deviceName());
        netPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    if (receiver != null) receiver.stop();
                    File d = dest != null ? new File(dest) : new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "FileZen");
                    FzNet.Receiver rx = new FzNet.Receiver(name, d, xl);
                    int port = FzNet.PORT;
                    IOException last = null;
                    for (int i = 0; i < 6; i++) {
                        try { port = rx.start(FzNet.PORT + i); last = null; break; } catch (IOException e) { last = e; }
                    }
                    if (last != null) throw last;
                    receiver = rx;
                    JSObject r = new JSObject();
                    r.put("port", port);
                    r.put("name", name);
                    r.put("dest", d.getAbsolutePath());
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        });
    }

    @PluginMethod
    public void xferStop(PluginCall call) {
        FzNet.Receiver rx = receiver;
        receiver = null;
        if (rx != null) rx.stop();
        call.resolve();
    }

    @PluginMethod
    public void xferAnswer(PluginCall call) {
        FzNet.Receiver rx = receiver;
        String id = call.getString("id");
        if (rx != null && id != null) rx.answer(id, Boolean.TRUE.equals(call.getBoolean("accept", Boolean.FALSE)));
        call.resolve();
    }

    @PluginMethod
    public void xferCancel(PluginCall call) {
        String id = call.getString("id");
        if (id != null) {
            FzNet.Token t = sends.get(id);
            if (t != null) t.cancel();
            FzNet.Receiver rx = receiver;
            if (rx != null) rx.cancel(id);
        }
        call.resolve();
    }

    @PluginMethod
    public void xferScan(final PluginCall call) {
        final String key = "scan";
        final FzNet.Token tk = new FzNet.Token();
        FzNet.Token old = sends.put(key, tk);
        if (old != null) old.cancel();
        netPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    int n = FzNet.scan(FzNet.PORT, 380, new FzNet.Listener() {
                        @Override
                        void onPeer(String ip, int port, String name) {
                            JSObject o = new JSObject();
                            o.put("ip", ip);
                            o.put("port", port);
                            o.put("name", name);
                            notifyListeners("xferPeer", o);
                        }
                    }, tk);
                    JSObject r = new JSObject();
                    r.put("count", n);
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                } finally {
                    sends.remove(key, tk);
                }
            }
        });
    }

    @PluginMethod
    public void xferProbe(final PluginCall call) {
        final String ip = call.getString("ip");
        Integer p = call.getInt("port", FzNet.PORT);
        final int port = p == null ? FzNet.PORT : p;
        if (ip == null) {
            call.reject("ip is required");
            return;
        }
        netPool.execute(new Runnable() {
            @Override
            public void run() {
                String n = FzNet.probe(ip, port, 1500);
                JSObject r = new JSObject();
                r.put("name", n == null ? "" : n);
                call.resolve(r);
            }
        });
    }

    @PluginMethod
    public void xferSend(final PluginCall call) {
        final String id = call.getString("id", "send");
        final String ip = call.getString("ip");
        Integer p = call.getInt("port", FzNet.PORT);
        final int port = p == null ? FzNet.PORT : p;
        final String name = call.getString("name", deviceName());
        final JSArray arr = call.getArray("items");
        if (ip == null || arr == null || arr.length() == 0) {
            call.reject("nothing to send");
            return;
        }
        final FzNet.Token tk = new FzNet.Token();
        sends.put(id, tk);
        netPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    List<File> files = new ArrayList<File>();
                    List<String> rels = new ArrayList<String>();
                    for (int i = 0; i < arr.length(); i++) {
                        org.json.JSONObject o = arr.getJSONObject(i);
                        files.add(new File(o.getString("path")));
                        rels.add(o.optString("rel", ""));
                    }
                    List<FzNet.Item> items = FzNet.expand(files, rels);
                    if (items.isEmpty()) {
                        xl.onDone(id, "send", false, 0, 0, null, "Nothing readable to send");
                    } else {
                        FzNet.send(ip, port, name, items, id, xl, tk);
                    }
                    call.resolve();
                } catch (Throwable e) {
                    xl.onDone(id, "send", false, 0, 0, null, msg(e));
                    call.resolve();
                } finally {
                    sends.remove(id, tk);
                }
            }
        });
    }

    /** Keeps the screen on while AirLink is open so a long transfer is never paused by sleep. */
    @PluginMethod
    public void keepAwake(PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", Boolean.FALSE));
        if (getActivity() == null) {
            call.resolve();
            return;
        }
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Window w = getActivity().getWindow();
                    if (on) w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    else w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                } catch (Throwable ignored) {}
            }
        });
        call.resolve();
    }

    /* ---------- installed apps (for "send an app") ---------- */

    @PluginMethod
    public void appsList(final PluginCall call) {
        ioPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    PackageManager pm = getContext().getPackageManager();
                    List<ApplicationInfo> all = pm.getInstalledApplications(0);
                    List<JSObject> rows = new ArrayList<JSObject>();
                    String me = getContext().getPackageName();
                    for (ApplicationInfo ai : all) {
                        boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                        if (sys || me.equals(ai.packageName) || ai.sourceDir == null) continue;
                        JSObject o = new JSObject();
                        long size = new File(ai.sourceDir).length();
                        JSArray splits = new JSArray();
                        if (ai.splitSourceDirs != null) {
                            for (String sp : ai.splitSourceDirs) {
                                splits.put(sp);
                                size += new File(sp).length();
                            }
                        }
                        o.put("pkg", ai.packageName);
                        o.put("name", String.valueOf(pm.getApplicationLabel(ai)));
                        o.put("apk", ai.sourceDir);
                        o.put("splits", splits);
                        o.put("size", size);
                        rows.add(o);
                    }
                    java.util.Collections.sort(rows, new java.util.Comparator<JSObject>() {
                        @Override
                        public int compare(JSObject a, JSObject b) {
                            return a.optString("name").compareToIgnoreCase(b.optString("name"));
                        }
                    });
                    JSArray out = new JSArray();
                    for (JSObject o : rows) out.put(o);
                    JSObject r = new JSObject();
                    r.put("apps", out);
                    r.put("total", all.size());
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        });
    }

    @PluginMethod
    public void appIcon(final PluginCall call) {
        final String pkg = call.getString("pkg");
        if (pkg == null) {
            call.reject("pkg is required");
            return;
        }
        thumbPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    File out = new File(thumbDir(), "app_" + sha1(pkg) + ".png");
                    if (!out.exists() || out.length() == 0) {
                        PackageManager pm = getContext().getPackageManager();
                        ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                        Drawable d = ai.loadIcon(pm);
                        Bitmap b = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888);
                        Canvas c = new Canvas(b);
                        d.setBounds(0, 0, 128, 128);
                        d.draw(c);
                        FileOutputStream fo = new FileOutputStream(out);
                        try { b.compress(Bitmap.CompressFormat.PNG, 100, fo); } finally { fo.close(); }
                        b.recycle();
                    }
                    JSObject r = new JSObject();
                    r.put("path", out.getAbsolutePath());
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject(msg(e));
                }
            }
        });
    }
}
