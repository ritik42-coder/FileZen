package com.filezen.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.lang.reflect.Method;

/**
 * The single native plugin FileZen needs.
 *
 * Deliberately imports nothing outside the Android framework and Capacitor core:
 * - FileProvider is reached through reflection, so the app still compiles when the
 *   androidx.core dependency is not on the app module's classpath, and still works
 *   when the provider is declared in the manifest.
 * - Everything degrades to a rejected call instead of a crash.
 */
@CapacitorPlugin(name = "Perm")
public class PermPlugin extends Plugin {

    /* ---------- storage permission + totals ---------- */

    @PluginMethod
    public void check(PluginCall call) {
        JSObject o = new JSObject();
        boolean granted = Build.VERSION.SDK_INT >= 30 ? Environment.isExternalStorageManager() : true;
        long total = 0L;
        long free = 0L;
        try {
            StatFs s = new StatFs(Environment.getExternalStorageDirectory().getPath());
            total = s.getTotalBytes();
            free = s.getAvailableBytes();
        } catch (Exception ignored) {}
        o.put("granted", granted);
        o.put("total", total);
        o.put("free", free);
        call.resolve(o);
    }

    @PluginMethod
    public void request(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            }
        } catch (Exception ignored) {}
        call.resolve();
    }

    /* ---------- status / navigation bar colours ---------- */

    @PluginMethod
    public void setBars(PluginCall call) {
        final String status = call.getString("status", "#0B0B0D");
        final String nav = call.getString("nav", "#0B0B0D");
        final boolean lightIcons = Boolean.TRUE.equals(call.getBoolean("light", Boolean.FALSE));
        if (getActivity() == null) {
            call.resolve();
            return;
        }
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Window w = getActivity().getWindow();
                    w.setStatusBarColor(Color.parseColor(status));
                    w.setNavigationBarColor(Color.parseColor(nav));
                    View dv = w.getDecorView();
                    int flags = dv.getSystemUiVisibility();
                    if (lightIcons) {
                        flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    } else {
                        flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    }
                    dv.setSystemUiVisibility(flags);
                } catch (Exception ignored) {}
            }
        });
        call.resolve();
    }

    /* ---------- open with / share ---------- */

    private Uri uriFor(String path) throws Exception {
        File f = new File(path);
        Class<?> cls = Class.forName("androidx.core.content.FileProvider");
        Method m = cls.getMethod("getUriForFile", Context.class, String.class, File.class);
        return (Uri) m.invoke(null, getContext(),
                getContext().getPackageName() + ".fileprovider", f);
    }

    @PluginMethod
    public void open(PluginCall call) {
        String path = call.getString("path");
        String mime = call.getString("mime", "*/*");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uriFor(path), mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("cannot open: " + e.getMessage());
        }
    }

    @PluginMethod
    public void share(PluginCall call) {
        String path = call.getString("path");
        String mime = call.getString("mime", "*/*");
        String title = call.getString("title", "Share");
        if (path == null) {
            call.reject("path is required");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_STREAM, uriFor(path));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(i, title);
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("cannot share: " + e.getMessage());
        }
    }
}
