package com.filezen.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "Perm")
public class PermPlugin extends Plugin {
    @PluginMethod
    public void check(PluginCall call) {
        JSObject o = new JSObject();
        boolean g = Build.VERSION.SDK_INT >= 30 ? Environment.isExternalStorageManager() : true;
        StatFs s = new StatFs(Environment.getExternalStorageDirectory().getPath());
        o.put("granted", g);
        o.put("total", s.getTotalBytes());
        o.put("free", s.getAvailableBytes());
        call.resolve(o);
    }

    @PluginMethod
    public void request(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 30) {
            Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        }
        call.resolve();
    }
}
